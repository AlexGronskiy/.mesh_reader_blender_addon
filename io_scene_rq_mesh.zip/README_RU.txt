Royal Quest Mesh Tools v0.1.20

Это версия для Blender 4.2+ через Extensions / Install from Disk.
В архиве blender_manifest.toml лежит в корне архива.

Что изменено в v0.1.20:
- Исправлено подключение alpha у обычных DXT5 diffuse-текстур.
- Наличие alpha-канала в *_dxt5.dds больше не означает прозрачность материала.
- Пример: bookcase_05.mesh / library_lev_01_dxt5.dds теперь импортируется как OPAQUE, без подключения картинки в Principled BSDF Alpha.
- Alpha подключается только для текстур с прозрачной ролью в имени: alpha, decal, glass, window, leaves, foliage, grass, plant, banner, flag, smoke и т.п.
- В material custom properties сохраняется rq_alpha_reason, чтобы видеть, почему alpha включена или отключена.

Сохранено из прошлых версий:
- UV читаются как штатный RQ fixed-point формат signed int16 / 16384.
- Пустые material slots сохраняются, поэтому индексы материалов не сдвигаются.
- *_spec_dxt*.dds и *_diff__*_spec_dxt*.dds остаются непрозрачными, потому что их alpha обычно spec/mask, а не прозрачность.
- Drag-and-drop импорт .mesh прямо в окно Blender.
- RQ Z 180° correction.
- Счётчик индексов читается как количество треугольников.

Рекомендуемые настройки импорта:
- Flip V: включено.
- UV scale: Auto.
- RQ Z 180° correction: включено.
- Texture root: папка, внутри которой есть textures, например rq_extracted, или сама папка textures.

Установка:
1) Закрыть Blender.
2) Удалить старую папку, если есть:
   %APPDATA%\Blender Foundation\Blender\<версия>\extensions\user_default\io_scene_rq_mesh
3) Blender -> Edit -> Preferences.
4) Extensions или Get Extensions.
5) Install from Disk.
6) Выбрать io_scene_rq_mesh_extension_v0_1_20.zip.
7) Включить расширение Royal Quest Mesh Tools.

После включения:
File -> Import -> Royal Quest (.mesh)
File -> Export -> Royal Quest (.mesh)

Drag-and-drop:
- Просто перетащи .mesh файл в окно Blender, лучше прямо во Viewport.
- Для текстур при drag-and-drop можно один раз указать Texture root в настройках расширения.
