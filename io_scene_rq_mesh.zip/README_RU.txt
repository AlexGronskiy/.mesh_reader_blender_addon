Royal Quest .mesh Blender Add-on v0.1.27

Royal Quest Mesh Tools v0.1.25

Это версия для Blender 4.2+ через Extensions / Install from Disk.
В архиве blender_manifest.toml лежит в корне архива.

Что изменено в v0.1.25:
- Полностью отключено подключение картинки материала в Principled BSDF -> Alpha.
- Все импортированные материалы теперь создаются как OPAQUE.
- Alpha-канал DXT5/TGA, если он есть в файле изображения, считается служебными данными текстуры, а не прозрачностью материала.
- У материала Alpha остаётся 1.000 без ссылки на Image Texture.
- Для уже созданного материала удаляются входящие связи в Alpha, если они случайно остались.

Сохранено из прошлых версий:
- Исправлено чтение multi-submesh .mesh в секции 3.
- UV читаются как штатный RQ fixed-point формат signed int16 / 16384.
- Пустые material slots сохраняются, поэтому индексы материалов не сдвигаются.
- Drag-and-drop импорт .mesh прямо в окно Blender.
- RQ Z 180° correction.
- Счётчик индексов читается как количество треугольников.
- Версия с .colmesh сюда не добавлялась, это продолжение старой .mesh-версии.

Рекомендуемые настройки импорта:
- Flip V: включено.
- UV scale: Auto.
- RQ Z 180° correction: включено.
- Texture root: папка, внутри которой есть textures, например rq_extracted, или сама папка textures.

Установка:
1) Закрыть Blender.
2) Удалить старую папку, если есть:
   %APPDATA%\Blender Foundation\Blender\<версия>\extensions\user_default\io_scene_rq_mesh
3) Blender -> Edit -> Preferences.
4) Extensions или Get Extensions.
5) Install from Disk.
6) Выбрать io_scene_rq_mesh_extension_v0_1_25.zip.
7) Включить расширение Royal Quest Mesh Tools.

После включения:
File -> Import -> Royal Quest (.mesh)
File -> Export -> Royal Quest (.mesh)

Drag-and-drop:
- Просто перетащи .mesh файл в окно Blender, лучше прямо во Viewport.
- Для текстур при drag-and-drop можно один раз указать Texture root в настройках расширения.
