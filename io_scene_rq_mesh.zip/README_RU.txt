Royal Quest Mesh Tools v0.1.10

Это версия для Blender 4.2+ через Extensions / Install from Disk.
В архиве blender_manifest.toml лежит в корне архива.

Что изменено в v0.1.10:
- Исправлена прозрачность у stone_river_001-006 и похожих моделей.
- Для текстур вида *_diff__*_spec_dxt5.dds / *_diff__*_spec_dxt1.dds alpha-канал больше не используется как прозрачность.
- Такие packed diffuse+spec DDS теперь принудительно подключаются как непрозрачные, потому что alpha там служебный/spec-канал, а не opacity.

Старые исправления сохранены:
- v0.1.8: исправлен критический баг v0.1.7 — возвращена функция сборки объекта Blender при импорте (_build_import_mesh).
- v0.1.7: добавлен поиск RQ-имен вида stones002_diff__stones002_spec_dxt5.dds и fallback-загрузчик DDS DXT1/DXT5.
- v0.1.6: счётчик индексов читается как количество треугольников.
- v0.1.5: UV Auto = x4 + signed seam UV fix.

Рекомендуемые настройки импорта:
- Flip V: включено.
- UV scale: Auto.
- Texture root: лучше указывать папку, внутри которой есть textures, например rq_extracted, или саму папку textures.

Установка:
1) Закрыть Blender.
2) Удалить старую папку:
   %APPDATA%\Blender Foundation\Blender\<версия>\extensions\user_default\io_scene_rq_mesh
3) Blender -> Edit -> Preferences.
4) Extensions или Get Extensions.
5) Install from Disk.
6) Выбрать io_scene_rq_mesh_extension_v0_1_9.zip.
7) Включить расширение Royal Quest Mesh Tools.

После включения:
File -> Import -> Royal Quest (.mesh)
File -> Export -> Royal Quest (.mesh)
