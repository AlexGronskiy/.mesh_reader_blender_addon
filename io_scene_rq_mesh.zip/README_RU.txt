Royal Quest Mesh Tools v0.1.3

Это версия для Blender 4.2+ через Extensions / Install from Disk.
В архиве blender_manifest.toml лежит в корне архива.

Что изменено в v0.1.3:
- Исправлен импорт UV: по умолчанию V-координата теперь переворачивается как в исходном RQ Model Lab просмотрщике: (u, 1-v).
- В окно импорта добавлена галочка Flip V. Если какая-то отдельная модель внезапно станет зеркальной по вертикали, её можно импортировать с выключенной галкой.
- При экспорте через исходный template UV обратно записываются в RQ-формат, то есть round-trip не должен записывать уже перевёрнутые Blender-координаты как сырые игровые.

Установка:
1) Blender -> Edit -> Preferences.
2) Extensions или Get Extensions.
3) Install from Disk.
4) Выбрать io_scene_rq_mesh_extension_v0_1_3.zip.
5) Включить расширение Royal Quest Mesh Tools.

После включения:
File -> Import -> Royal Quest (.mesh)
File -> Export -> Royal Quest (.mesh)

Если Blender пишет Missing manifest, значит выбран не extension-архив, а legacy-архив.
