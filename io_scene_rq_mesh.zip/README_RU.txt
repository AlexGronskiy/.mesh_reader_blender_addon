Royal Quest Mesh Tools v0.1.28

Неофициальный Blender add-on для импорта и экспорта файлов Royal Quest .mesh.

Лицензия:
Apache License, Version 2.0.
Полный текст лицензии лежит в файле LICENSE.
Дополнительные уведомления лежат в файле NOTICE.

Автор и maintainer:
Alexander Gronskiy

Важно:
Это неофициальный инструмент. Проект не связан с разработчиками или издателями Royal Quest.
Royal Quest, игровые ассеты, названия, текстуры, модели и товарные знаки принадлежат их правообладателям.
Этот архив не даёт прав на сторонние игровые ассеты.

Что умеет аддон:
- импорт .mesh;
- экспорт .mesh;
- drag-and-drop .mesh прямо в окно Blender;
- импорт геометрии, UV и material slots;
- поиск текстур по Texture root;
- поддержка DDS DXT1/DXT5;
- template-based export для безопасного round-trip там, где это возможно.

Сохранено из текущей рабочей версии:
- UV читаются как RQ fixed-point формат signed int16 / 16384;
- пустые material slots сохраняются, поэтому индексы материалов не сдвигаются;
- исправлено чтение multi-submesh .mesh в секции 3;
- RQ Z 180° correction;
- счётчик индексов читается как количество треугольников;
- анализ настоящей alpha-маски у diffuse-текстур без автоматического подключения alpha у spec/packed-текстур;
- версия с .colmesh сюда не добавлялась.

Рекомендуемые настройки импорта:
- Flip V: включено;
- UV scale: Auto;
- RQ Z 180° correction: включено;
- Texture root: папка, внутри которой есть textures, например rq_extracted, или сама папка textures.

Установка в Blender 4.2+:
1) Закрой Blender.
2) Удали старую папку, если она есть:
   %APPDATA%\Blender Foundation\Blender\<версия>\extensions\user_default\io_scene_rq_mesh
3) Открой Blender.
4) Edit -> Preferences -> Extensions / Get Extensions.
5) Install from Disk.
6) Выбери ZIP-архив аддона.
7) Включи Royal Quest Mesh Tools.

После включения:
File -> Import -> Royal Quest (.mesh)
File -> Export -> Royal Quest (.mesh)

Drag-and-drop:
Перетащи .mesh файл прямо в окно Blender, лучше во Viewport.
Для текстур при drag-and-drop можно один раз указать Texture root в настройках расширения.
