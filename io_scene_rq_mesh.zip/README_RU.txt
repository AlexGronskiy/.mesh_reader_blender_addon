Royal Quest Mesh Tools v0.1.14

Это версия для Blender 4.2+ через Extensions / Install from Disk.
В архиве blender_manifest.toml лежит в корне архива.

Что изменено в v0.1.14:
- Исправлено подключение материалов: diffuse/DXT5-текстура больше не подключается в Alpha вход Principled BSDF автоматически.
- Материалы импортируются непрозрачными, Alpha остаётся 1.0, чтобы служебные packed-каналы RQ не делали модель прозрачной.
- Добавлен drag-and-drop импорт .mesh прямо в окно Blender.
- Можно перетаскивать один .mesh или несколько .mesh сразу.
- Добавлены настройки drag-and-drop в Preferences -> Extensions -> Royal Quest Mesh Tools:
  * Drag-and-drop Texture root
  * Drag-and-drop Flip V
  * Drag-and-drop UV scale
- Обычный импорт через File -> Import -> Royal Quest (.mesh) сохранён.

Старые исправления из присланной версии сохранены:
- Исправлена прозрачность у некоторых моделей.
- Для текстур вида *_diff__*_spec_dxt5.dds / *_diff__*_spec_dxt1.dds alpha-канал больше не используется как прозрачность.
- Такие packed diffuse+spec DDS принудительно подключаются как непрозрачные, потому что alpha там служебный/spec-канал, а не opacity.
- v0.1.8: исправлен критический баг v0.1.7 — возвращена функция сборки объекта Blender при импорте (_build_import_mesh).
- v0.1.7: добавлен поиск RQ-имен вида stones002_diff__stones002_spec_dxt5.dds и fallback-загрузчик DDS DXT1/DXT5.
- v0.1.6: счётчик индексов читается как количество треугольников.
- v0.1.5: UV Auto = x4 + signed seam UV fix.

Рекомендуемые настройки импорта:
- Flip V: включено.
- UV scale: Auto.
- Texture root: лучше указывать папку, внутри которой есть textures, например rq_extracted, или саму папку textures.

Установка:
1) Закрыть Blender.
2) Удалить старую папку, если есть:
   %APPDATA%\Blender Foundation\Blender\<версия>\extensions\user_default\io_scene_rq_mesh
3) Blender -> Edit -> Preferences.
4) Extensions или Get Extensions.
5) Install from Disk.
6) Выбрать io_scene_rq_mesh.zip.
7) Включить расширение Royal Quest Mesh Tools.

После включения:
File -> Import -> Royal Quest (.mesh)
File -> Export -> Royal Quest (.mesh)

Drag-and-drop:
- Просто перетащи .mesh файл в окно Blender, лучше прямо во Viewport.
- Для текстур при drag-and-drop можно один раз указать Texture root в настройках расширения.


Изменения v0.1.14:
- alpha у реальных прозрачных diffuse/decal/window текстур снова подключается к материалу автоматически;
- *_spec_dxt*.dds и *_diff__*_spec_dxt*.dds остаются непрозрачными, потому что их alpha обычно spec/mask, а не прозрачность;
- drag-and-drop и RQ Z 180° correction сохранены.
