# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Alexander Gronskiy

# SPDX-License-Identifier: GPL-3.0-or-later
#
# RQ .mesh Blender Add-on
# Copyright (C) 2026 Alexander Gronskiy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.

bl_info = {
    "name": "Royal Quest .mesh Import/Export",
    "author": "OpenAI / based on RQ_Model_Lab_v21 parser",
    "version": (0, 1, 21),
    "blender": (3, 6, 0),
    "location": "File > Import/Export > Royal Quest (.mesh)",
    "description": "Import and export Royal Quest .mesh files. Geometry/UV/material import; safe template-based export when possible.",
    "category": "Import-Export",
}

import json
import math
import re
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper
from mathutils import Matrix, Vector

try:
    import bmesh
except Exception:  # pragma: no cover - Blender provides bmesh
    bmesh = None

CHUNK_HEADER = 12
META_PROP = "rq_mesh_metadata"
SOURCE_PATH_PROP = "rq_mesh_source_path"
TEXTURE_PATH_PROP = "rq_texture_path"
RESOLVED_TEXTURE_PATH_PROP = "rq_texture_resolved_path"
RQ_Z_ROTATION_FIX_PROP = "rq_z_rotation_fix"
TRANSPARENT_ALPHA_PROP = "rq_texture_uses_alpha"

UV_SCALE_MODE_ITEMS = (
    ("AUTO", "Auto", "Штатное чтение RQ UV как signed int16 / 16384; швы повторяющихся UV исправляются per-face"),
    ("ONE", "x1 / unsigned", "Сырые 16-битные UV читать как unsigned 0..1; только для диагностики нестандартных файлов"),
    ("FOUR", "signed x4 / RQ", "Штатный fixed-point режим RQ: signed int16 / 16384"),
)

ADDON_PREFERENCES_ID = __package__ or __name__


def _addon_preferences(context: bpy.types.Context | None = None) -> Any | None:
    try:
        preferences = (context or bpy.context).preferences
        for addon_id in (ADDON_PREFERENCES_ID, __package__, __name__, "io_scene_rq_mesh"):
            if not addon_id:
                continue
            addon = preferences.addons.get(addon_id)
            if addon is not None:
                return addon.preferences
    except Exception:
        return None
    return None



# -----------------------------------------------------------------------------
# Low-level .mesh helpers copied/adapted from RQ_Model_Lab_v21/rq_lab/formats.
# -----------------------------------------------------------------------------


def u32(data: bytes | bytearray, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def put_u32(data: bytearray, off: int, value: int) -> None:
    struct.pack_into("<I", data, off, int(value) & 0xFFFFFFFF)


@dataclass(frozen=True)
class Section:
    section_id: int
    offset: int
    end: int

    @property
    def size(self) -> int:
        return self.end - self.offset


def parse_sections(data: bytes) -> tuple[int, int, list[Section]]:
    if len(data) < 8:
        raise ValueError("Файл слишком маленький")

    declared_size = u32(data, 0)
    section_count = u32(data, 4)
    if section_count <= 0 or section_count > 512:
        raise ValueError(f"Подозрительное число секций: {section_count}")

    table_end = 8 + section_count * 8
    if table_end > len(data):
        raise ValueError("Таблица секций выходит за пределы файла")

    entries: list[tuple[int, int, int]] = []
    for i in range(section_count):
        pos = 8 + i * 8
        entries.append((i, u32(data, pos), u32(data, pos + 4)))

    sorted_offsets = sorted(off for _idx, _sid, off in entries if 0 < off <= len(data))
    sections: list[Section] = []
    for _idx, section_id, offset in entries:
        if offset >= len(data):
            end = len(data)
        else:
            next_offsets = [x for x in sorted_offsets if x > offset]
            end = next_offsets[0] if next_offsets else len(data)
        if end < offset:
            end = offset
        sections.append(Section(section_id, offset, end))
    return declared_size, section_count, sections


def section_bytes(data: bytes, sections: list[Section], section_id: int) -> bytes | None:
    for section in sections:
        if section.section_id == section_id:
            return data[section.offset : section.end]
    return None


def section_by_id(sections: list[Section], section_id: int) -> Section | None:
    for section in sections:
        if section.section_id == section_id:
            return section
    return None


def _read_cstring(data: bytes, offset: int) -> str:
    end = data.find(b"\x00", offset)
    if end == -1:
        end = len(data)
    return data[offset:end].decode("ascii", errors="replace")


def _decode_packed_normal(packed: int) -> tuple[float, float, float]:
    x = ((packed >> 0) & 0x3FF) / 511.0 * 2.0 - 1.0
    y = ((packed >> 10) & 0x3FF) / 511.0 * 2.0 - 1.0
    z = ((packed >> 20) & 0x3FF) / 511.0 * 2.0 - 1.0
    length = math.sqrt(x * x + y * y + z * z)
    if length < 1e-6:
        return (0.0, 0.0, 1.0)
    return (x / length, y / length, z / length)


def _encode_packed_normal(normal: tuple[float, float, float] | Vector) -> int:
    x, y, z = float(normal[0]), float(normal[1]), float(normal[2])
    length = math.sqrt(x * x + y * y + z * z)
    if length < 1e-6:
        x, y, z = 0.0, 0.0, 1.0
    else:
        x, y, z = x / length, y / length, z / length

    def enc(v: float) -> int:
        return max(0, min(1023, int(round((max(-1.0, min(1.0, v)) + 1.0) * 511.0 * 0.5))))

    return enc(x) | (enc(y) << 10) | (enc(z) << 20)


def _uv_offset_and_scale(stride: int, uv_scale: float | None = None) -> tuple[int, float]:
    if stride >= 20:
        scale_value = 4.0 if uv_scale is None else float(uv_scale)
        if scale_value <= 0.0:
            scale_value = 4.0
        return 12, scale_value / 65535.0
    return 0, 0.0


def _choose_uv_scale(chunk: bytes, vertex_count: int, stride: int, uv_scale_mode: str = "AUTO") -> float:
    mode = str(uv_scale_mode or "AUTO").upper()
    if mode in {"ONE", "X1", "1", "1X", "UNSIGNED"}:
        return 1.0

    # Проверка архива meshes.zip показала, что штатные RQ UV лежат не как
    # unsigned 0..4, а как signed fixed-point: int16 / 16384.
    # Это тот же масштаб x4, но старший диапазон 0x8000..0xFFFF является
    # отрицательными UV, а не координатами 2..4. Если читать их как unsigned,
    # у моделей вроде sidewalk_01 появляются огромные UV-иглы вправо, а у
    # nymphaea_01 одна seam-точка улетает к V=4.
    return 4.0

def _read_vertex_uv(chunk: bytes, base: int, stride: int, uv_scale: float = 4.0) -> tuple[float, float]:
    offset, scale = _uv_offset_and_scale(stride, uv_scale)
    if offset <= 0 or base + offset + 4 > len(chunk):
        return (0.0, 0.0)

    scale_value = float(uv_scale)
    if scale_value > 1.0:
        # Нормальный формат Royal Quest .mesh: две signed int16 координаты
        # с fixed-point масштабом 1/16384. Это даёт диапазон примерно -2..2
        # и корректно сохраняет отрицательные seam/atlas UV.
        raw_u, raw_v = struct.unpack_from("<hh", chunk, base + offset)
        return (raw_u / 16384.0, raw_v / 16384.0)

    # Диагностический режим x1: читать как обычный unsigned normalized 0..1.
    raw_u, raw_v = struct.unpack_from("<HH", chunk, base + offset)
    return (raw_u * scale, raw_v * scale)

def _write_vertex_uv(raw: bytearray, base: int, stride: int, uv: tuple[float, float], uv_scale: float = 4.0) -> None:
    offset, _scale = _uv_offset_and_scale(stride, uv_scale)
    if offset <= 0 or base + offset + 4 > len(raw):
        return

    scale_value = float(uv_scale)
    if scale_value > 1.0:
        def enc_signed(value: float) -> int:
            encoded = int(round(float(value) * 16384.0))
            return max(-32768, min(32767, encoded))

        struct.pack_into("<h", raw, base + offset, enc_signed(uv[0]))
        struct.pack_into("<h", raw, base + offset + 2, enc_signed(uv[1]))
        return

    def enc_unsigned(value: float) -> int:
        encoded = int(round(float(value) * 65535.0))
        return max(0, min(65535, encoded))

    struct.pack_into("<H", raw, base + offset, enc_unsigned(uv[0]))
    struct.pack_into("<H", raw, base + offset + 2, enc_unsigned(uv[1]))


def _rq_uv_to_blender(uv: tuple[float, float], flip_v: bool = True) -> tuple[float, float]:
    u, v = float(uv[0]), float(uv[1])
    if flip_v:
        v = 1.0 - v
    return (u, v)


def _blender_uv_to_rq(uv: tuple[float, float], flip_v: bool = True) -> tuple[float, float]:
    u, v = float(uv[0]), float(uv[1])
    if flip_v:
        v = 1.0 - v
    return (u, v)


def _unwrap_axis_values_for_repeating_texture(values: list[float], period: float = 1.0) -> list[float]:
    if len(values) <= 1 or period <= 0.0:
        return values[:]

    original_span = max(values) - min(values)

    # Обычные 0..1 полигоны не трогаем: треугольник с UV 0->1 должен
    # показывать один полный тайл. Исправляем только явные wrap/seam
    # ситуации, когда вершины одного треугольника оказались на разных
    # повторениях текстуры, например -0.01 рядом с 0.99 или 1.99 рядом с 0.01.
    if original_span <= 1.5 * period:
        return values[:]

    best = values[:]
    best_span = original_span

    # Перебираем каждую вершину как опорную, потому что у разных моделей seam
    # может находиться с любой стороны треугольника. Это общая UV-нормализация,
    # а не привязка к конкретному имени меша.
    for reference in values:
        shifted = [value + round((reference - value) / period) * period for value in values]
        span = max(shifted) - min(shifted)
        if span < best_span:
            best = shifted
            best_span = span

    if best_span + 1e-6 < original_span - period:
        return best
    return values[:]


def _unwrap_triangle_uvs_for_blender(uvs: list[tuple[float, float]], flip_v: bool = True) -> list[tuple[float, float]]:
    converted = [_rq_uv_to_blender(uv, flip_v) for uv in uvs]
    if len(converted) != 3:
        return converted

    u_values = _unwrap_axis_values_for_repeating_texture([uv[0] for uv in converted], 1.0)
    v_values = _unwrap_axis_values_for_repeating_texture([uv[1] for uv in converted], 1.0)
    return [(u_values[i], v_values[i]) for i in range(3)]

def _read_vertex_normal(chunk: bytes, base: int, stride: int) -> tuple[float, float, float]:
    if stride >= 20:
        packed = struct.unpack_from("<I", chunk, base + 16)[0]
        return _decode_packed_normal(packed)
    if stride >= 16:
        packed = struct.unpack_from("<I", chunk, base + 12)[0]
        return _decode_packed_normal(packed)
    return (0.0, 0.0, 1.0)


def _write_vertex_normal(raw: bytearray, base: int, stride: int, normal: tuple[float, float, float] | Vector) -> None:
    if stride >= 20 and base + 20 <= len(raw):
        struct.pack_into("<I", raw, base + 16, _encode_packed_normal(normal))
    elif stride >= 16 and base + 16 <= len(raw):
        struct.pack_into("<I", raw, base + 12, _encode_packed_normal(normal))


def _read_index_count(chunk: bytes, index_offset: int) -> tuple[int, int, int] | None:
    if index_offset + 4 > len(chunk):
        return None

    raw_index_count = u32(chunk, index_offset)
    if raw_index_count <= 0 or raw_index_count > 5_000_000:
        return None

    index_data_offset = index_offset + 4

    # In confirmed Royal Quest .mesh files this field stores TRIANGLE count,
    # not literal index count. Every triangle has 3 uint16 indices. Older
    # addon versions treated values like 130/92/1362 as index counts and then
    # tried to recover the rest from a fake "tail", which dropped the last
    # triangle on meshes such as stone_wall_01/02 and nymphaea_01.
    triangle_index_count = raw_index_count * 3
    if index_data_offset + triangle_index_count * 2 <= len(chunk):
        return raw_index_count, triangle_index_count, index_data_offset

    # Fallback for unknown variants, if a file really stores literal index
    # count. Keep it strict: face indices still must form full triangles.
    if raw_index_count >= 3 and raw_index_count % 3 == 0:
        if index_data_offset + raw_index_count * 2 <= len(chunk):
            return raw_index_count, raw_index_count, index_data_offset

    return None


def _geometry_chunk_byte_size(chunk: bytes) -> int | None:
    if len(chunk) < CHUNK_HEADER + 16:
        return None

    vertex_count = u32(chunk, 4)
    stride = u32(chunk, 8)
    if not (3 <= vertex_count <= 500_000):
        return None
    if stride not in range(12, 65):
        return None

    index_offset = CHUNK_HEADER + vertex_count * stride
    index_info = _read_index_count(chunk, index_offset)
    if index_info is None:
        return None
    _raw_index_count, index_count, index_data_offset = index_info
    if index_count <= 0 or index_count % 3 != 0:
        return None
    if index_data_offset + index_count * 2 > len(chunk):
        return None

    indices = struct.unpack_from(f"<{index_count}H", chunk, index_data_offset)
    if not indices or max(indices) >= vertex_count:
        return None

    return index_data_offset + index_count * 2


@dataclass
class MeshChunk:
    vertices: list[tuple[float, float, float]]
    normals: list[tuple[float, float, float]]
    uvs: list[tuple[float, float]]
    indices: list[int]
    vertex_count: int
    stride: int
    texture_index: int = 0
    uv_scale: float = 4.0
    geom_offset: int = 0
    chunk_size: int = 0
    raw_index_count: int = 0
    primary_index_count: int = 0
    primary_index_data_offset: int = 0
    tail_index_count: int = 0
    tail_index_data_offset: int = 0


@dataclass
class MeshData:
    path: Path
    file_size: int
    declared_size: int
    textures: list[str] = field(default_factory=list)
    animblock_path: str | None = None
    chunks: list[MeshChunk] = field(default_factory=list)
    bone_palette: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def vertex_count(self) -> int:
        return sum(chunk.vertex_count for chunk in self.chunks)

    @property
    def triangle_count(self) -> int:
        return sum(len(chunk.indices) // 3 for chunk in self.chunks)


def _parse_geometry_chunk(chunk: bytes, geom_offset: int, texture_index: int, uv_scale_mode: str = "AUTO") -> MeshChunk | None:
    if len(chunk) < CHUNK_HEADER + 16:
        return None

    vertex_count = u32(chunk, 4)
    stride = u32(chunk, 8)
    if not (3 <= vertex_count <= 500_000):
        return None
    if stride not in range(12, 65):
        return None

    vertex_start = CHUNK_HEADER
    vertex_bytes = vertex_count * stride
    index_offset = vertex_start + vertex_bytes
    if index_offset + 4 > len(chunk):
        return None

    index_info = _read_index_count(chunk, index_offset)
    if index_info is None:
        return None
    raw_index_count, index_count, index_data_offset = index_info
    if index_count <= 0 or index_count % 3 != 0:
        return None
    if index_data_offset + index_count * 2 > len(chunk):
        return None

    indices = list(struct.unpack_from(f"<{index_count}H", chunk, index_data_offset))
    if not indices or max(indices) >= vertex_count:
        return None

    uv_scale = _choose_uv_scale(chunk, vertex_count, stride, uv_scale_mode)

    vertices: list[tuple[float, float, float]] = []
    normals: list[tuple[float, float, float]] = []
    uvs: list[tuple[float, float]] = []
    for i in range(vertex_count):
        base = vertex_start + i * stride
        px, py, pz = struct.unpack_from("<3f", chunk, base)
        vertices.append((px, py, pz))
        normals.append(_read_vertex_normal(chunk, base, stride))
        uvs.append(_read_vertex_uv(chunk, base, stride, uv_scale))

    return MeshChunk(
        vertices=vertices,
        normals=normals,
        uvs=uvs,
        indices=indices,
        vertex_count=vertex_count,
        stride=stride,
        texture_index=texture_index,
        uv_scale=uv_scale,
        geom_offset=geom_offset,
        chunk_size=len(chunk),
        raw_index_count=raw_index_count,
        primary_index_count=index_count,
        primary_index_data_offset=index_data_offset,
        tail_index_count=0,
        tail_index_data_offset=0,
    )


def _is_submesh_base(geom: bytes, base: int) -> bool:
    if base + 0x34 > len(geom):
        return False
    if u32(geom, base + 8) != 5:
        return False
    if u32(geom, base + 0x10) != 0x30 or u32(geom, base + 0x14) != 1:
        return False
    if u32(geom, base + 0x1C) != 0xFFFFFFFF:
        return False
    if u32(geom, base + 0x20) != 0x54 or u32(geom, base + 0x24) != 2:
        return False
    rel = u32(geom, base + 0x28)
    sid = u32(geom, base + 0x2C)
    if sid != 4:
        return False
    abs_off = base + rel if base else rel
    if abs_off + 12 > len(geom):
        return False
    vertex_count = u32(geom, abs_off + 4)
    stride = u32(geom, abs_off + 8)
    return 3 <= vertex_count <= 500_000 and stride in range(12, 65)


def _find_submesh_bases(geom: bytes) -> list[int]:
    bases: set[int] = {0}
    if len(geom) >= 8 and u32(geom, 0) >= 2:
        second_base = u32(geom, 4)
        if 0x30 < second_base < len(geom):
            bases.add(second_base)
    for base in range(0, max(0, len(geom) - 0x60)):
        if base in bases or u32(geom, base + 8) != 5:
            continue
        if _is_submesh_base(geom, base):
            bases.add(base)
    return sorted(bases)


def _collect_geometry_offsets(geom: bytes, base: int = 0) -> list[int]:
    offsets: list[int] = []
    if base + 12 > len(geom):
        return offsets
    inner_count = u32(geom, base + 8) if base else u32(geom, 8)
    if inner_count != 5:
        return offsets
    for i in range(inner_count):
        entry = base + 0x10 + i * 8
        if entry + 8 > len(geom):
            continue
        rel = u32(geom, entry)
        section_id = u32(geom, entry + 4)
        if section_id not in (0, 4):
            continue
        offset = rel if base == 0 else base + rel
        if 0 < offset < len(geom):
            offsets.append(offset)
    return sorted(set(offsets))


def _parse_geometry_section(geom: bytes, warnings: list[str], uv_scale_mode: str = "AUTO") -> list[MeshChunk]:
    if len(geom) < 16:
        warnings.append("Секция геометрии слишком мала")
        return []

    chunks: list[MeshChunk] = []
    seen_offsets: set[int] = set()
    bases = _find_submesh_bases(geom)
    for texture_index, base in enumerate(bases):
        offsets = _collect_geometry_offsets(geom, base)
        for offset in offsets:
            if offset in seen_offsets:
                continue
            chunk_size = _geometry_chunk_byte_size(geom[offset:])
            if chunk_size is None:
                continue
            next_offsets = [x for x in offsets if x > offset]
            end = next_offsets[0] if next_offsets else len(geom)
            if end - offset < chunk_size:
                raw_chunk = geom[offset : offset + chunk_size]
            else:
                raw_chunk = geom[offset:end]
            parsed = _parse_geometry_chunk(raw_chunk, offset, texture_index, uv_scale_mode)
            if parsed is None:
                continue
            seen_offsets.add(offset)
            chunks.append(parsed)

    if not chunks:
        warnings.append("Не найдены блоки геометрии")
    return chunks


def _parse_bone_palette_from_geom(geom: bytes) -> list[str]:
    if len(geom) < 32:
        return []

    candidate_offsets: list[int] = []
    try:
        inner_count = u32(geom, 8)
        if 1 <= inner_count <= 32:
            for i in range(inner_count):
                rel = u32(geom, 0x10 + i * 8)
                section_id = u32(geom, 0x10 + i * 8 + 4)
                if section_id == 0 and 0 < rel < len(geom):
                    candidate_offsets.append(rel)
    except Exception:
        pass

    for off in range(0, max(0, len(geom) - 16), 4):
        if off in candidate_offsets:
            continue
        count = u32(geom, off + 4) if off + 8 <= len(geom) else 0
        if 1 <= count <= 512 and off + 8 < len(geom):
            first_zero = geom.find(b"\x00", off + 8, min(len(geom), off + 80))
            if first_zero > off + 8:
                name = geom[off + 8:first_zero]
                if all(32 <= b < 127 for b in name) and any(65 <= b <= 122 for b in name):
                    candidate_offsets.append(off)

    for off in candidate_offsets:
        if off + 8 > len(geom):
            continue
        count = u32(geom, off + 4)
        if not (1 <= count <= 512):
            continue
        pos = off + 8
        names: list[str] = []
        ok = True
        for _ in range(count):
            end = geom.find(b"\x00", pos, min(len(geom), pos + 96))
            if end <= pos:
                ok = False
                break
            raw = geom[pos:end]
            if not all(32 <= b < 127 for b in raw):
                ok = False
                break
            name = raw.decode("ascii", errors="replace")
            names.append(name)
            pos = end + 1 + 24
            if pos > len(geom) + 24:
                ok = False
                break
        if ok and len(names) == count:
            good_names = sum(1 for n in names if "_" in n or n in {"Head", "Chest", "Pelvis", "Spine", "Navel"})
            if good_names >= max(3, count // 8):
                return names
    return []


def _parse_texture_section(section: bytes) -> list[str]:
    """Read material texture entries while preserving material-slot indices.

    The texture section is not just a flat list of paths.  Each entry starts
    with a UTF-16LE material name, then a NUL-terminated ASCII texture path.
    Some meshes have a valid material slot with an empty path, for example
    tevton_tower_01.mesh has slot #0 = lambert1 with no texture and real
    textured slots start at #1.  Older add-on versions skipped empty paths;
    that shifted every following material by one and made buildings use the
    wrong textures.

    Therefore this function must return exactly one item per declared material
    entry when the structured format is valid.  Empty paths are intentionally
    kept as "" placeholders.
    """
    if len(section) >= 4:
        count = u32(section, 0)
        if 1 <= count <= 4096:
            pos = 4
            parsed: list[str] = []
            ok = True
            for _ in range(count):
                # Material name, stored as UTF-16LE code units and terminated
                # by a zero uint16.  We do not need the name for import, but
                # we must consume it to reach the ASCII texture path.
                name_terminated = False
                while pos + 2 <= len(section):
                    code = struct.unpack_from("<H", section, pos)[0]
                    pos += 2
                    if code == 0:
                        name_terminated = True
                        break
                if not name_terminated:
                    ok = False
                    break

                if pos > len(section):
                    ok = False
                    break

                end = section.find(b"\x00", pos)
                if end == -1:
                    ok = False
                    break

                path = section[pos:end].decode("ascii", errors="replace").replace("\\", "/")
                parsed.append(path)
                pos = end + 1

            if ok and len(parsed) == count:
                return parsed

    # Fallback for unknown/older variants: keep the old printable-string scan.
    # This cannot preserve empty material slots, but it is safer than returning
    # nothing for malformed sections.
    textures: list[str] = []
    for match in re.findall(rb"[\x20-\x7e]{4,}", section):
        value = match.decode("ascii", errors="replace").replace("\\", "/")
        if ("/" in value or "." in value) and value not in textures:
            textures.append(value)
    return textures

def parse_mesh(path: Path, uv_scale_mode: str = "AUTO") -> MeshData:
    data = path.read_bytes()
    declared_size, _section_count, sections = parse_sections(data)
    warnings: list[str] = []
    if declared_size != len(data):
        warnings.append(f"Размер в заголовке ({declared_size}) не совпадает с файлом ({len(data)})")

    textures: list[str] = []
    texture_section = section_bytes(data, sections, 2)
    if texture_section:
        textures = _parse_texture_section(texture_section)

    animblock_path: str | None = None
    anim_section = section_bytes(data, sections, 6)
    if anim_section:
        raw = _read_cstring(anim_section, 0).strip()
        if raw:
            animblock_path = raw.replace("\\", "/")

    geom_section = section_bytes(data, sections, 3)
    chunks: list[MeshChunk] = []
    bone_palette: list[str] = []
    if geom_section:
        chunks = _parse_geometry_section(geom_section, warnings, uv_scale_mode)
        bone_palette = _parse_bone_palette_from_geom(geom_section)
    else:
        warnings.append("Секция геометрии не найдена")

    if not chunks:
        warnings.append("Не удалось извлечь вершины/индексы")

    return MeshData(
        path=path.resolve(),
        file_size=len(data),
        declared_size=declared_size,
        textures=textures,
        animblock_path=animblock_path,
        chunks=chunks,
        bone_palette=bone_palette,
        warnings=warnings,
    )


# -----------------------------------------------------------------------------
# Blender material/import helpers.
# -----------------------------------------------------------------------------


def _safe_name(value: str, fallback: str) -> str:
    name = Path(value.replace("\\", "/")).name if value else ""
    name = name or fallback
    return name[:63]



def _texture_roots(mesh_path: Path, texture_root: str = "") -> list[Path]:
    roots: list[Path] = []
    if texture_root:
        try:
            roots.append(Path(bpy.path.abspath(texture_root)).resolve())
        except Exception:
            roots.append(Path(texture_root))

    # Важный момент для распакованного RQ: .mesh часто лежит внутри models/..., а
    # текстуры лежат рядом в textures/.... Поэтому проходим не только папку меша,
    # но и родителей до корня распаковки. Если меш был скопирован отдельно в
    # Downloads, автоматического поиска без Texture root уже быть не может.
    roots.append(mesh_path.parent)
    roots.extend(list(mesh_path.parents)[:10])

    unique: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        try:
            key = str(root.resolve()).lower()
        except Exception:
            key = str(root).lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(root)
    return unique



def _texture_ref_variants(texture_path: str) -> list[str]:
    normalized = str(texture_path or "").replace("\\", "/").lstrip("/").strip()
    if not normalized:
        return []

    rel = Path(normalized)
    parent = rel.parent.as_posix()
    stem = rel.stem
    stem_lower = stem.lower()

    names: list[str] = []

    def add(value: str) -> None:
        value = str(value or "").replace("\\", "/").lstrip("/").strip()
        if value and value not in names:
            names.append(value)

    def add_in_original_parent(filename: str) -> None:
        if parent and parent != ".":
            add(f"{parent}/{filename}")
        else:
            add(filename)

    def add_filename_variants(filename: str) -> None:
        # 1) точный путь из .mesh-поля / путь с исходной папкой
        add_in_original_parent(filename)
        # 2) только basename. Это нужно для маленьких asset-pack папок, где
        #    рядом с .mesh лежат только сами текстуры без полного дерева textures/...
        add(Path(filename).name)

    if rel.name:
        add(rel.as_posix())
        add(rel.name)

    # Обычные варианты: в .mesh обычно указан .tga, а на диске может лежать
    # DDS с постфиксом _dxt1/_dxt5. Порядок важен: сначала diffuse/base,
    # потом packed diffuse+spec, и только последним fallback — чистый spec.
    for ext in (".dds", ".tga", ".png"):
        add_filename_variants(f"{stem}{ext}")
    for tag in ("_dxt1", "_dxt5"):
        add_filename_variants(f"{stem}{tag}.dds")

    if stem_lower.endswith("_diff"):
        base = stem[: -len("_diff")]
        for ext in (".dds", ".tga", ".png"):
            add_filename_variants(f"{base}{ext}")
        for tag in ("_dxt1", "_dxt5"):
            add_filename_variants(f"{base}{tag}.dds")

        for spec_tag in ("_spec", "_Spec"):
            for dxt in ("_dxt5", "_dxt1"):
                add_filename_variants(f"{stem}__{base}{spec_tag}{dxt}.dds")

        for spec_tag in ("_spec", "_Spec"):
            for dxt in ("_dxt5", "_dxt1"):
                add_filename_variants(f"{base}{spec_tag}{dxt}.dds")

    # Модельный дебаггер/пакер часто кладёт текстуры в плоском виде:
    # mesh__textures__landscape__forest__stone_wall_02.tga
    # override__textures__landscape__forest_autumn__crown_maple_02_diff.tga
    # Старый поиск искал только настоящий путь textures/... и поэтому такие
    # asset-pack папки выглядели как "текстуры вообще не грузятся".
    current = list(names)
    for value in current:
        lower = value.lower()
        if not lower.startswith("textures/"):
            continue
        flat = value.replace("/", "__")
        add(f"mesh__{flat}")
        add(f"override__{flat}")

    return names

def _case_insensitive_existing_path(path: Path) -> Path | None:
    if path.is_file():
        return path

    # На Windows обычный exists уже регистронезависимый. Этот fallback нужен,
    # если аддон запускают на Linux/macOS или если архив распакован с другим
    # регистром папок Landscape/Forest вместо landscape/forest.
    try:
        parts = path.parts
        if not parts:
            return None
        current = Path(parts[0])
        if not current.exists() and path.is_absolute():
            return None
        for part in parts[1:]:
            if not current.is_dir():
                return None
            lower = part.lower()
            match = None
            for child in current.iterdir():
                if child.name.lower() == lower:
                    match = child
                    break
            if match is None:
                return None
            current = match
        return current if current.is_file() else None
    except Exception:
        return None



def _texture_candidates(texture_path: str, mesh_path: Path, texture_root: str = "") -> list[Path]:
    normalized = str(texture_path or "").replace("\\", "/").lstrip("/").strip()
    raw = Path(normalized)
    candidates: list[Path] = []

    if raw.is_absolute():
        candidates.append(raw)

    variants = _texture_ref_variants(normalized)
    roots = _texture_roots(mesh_path, texture_root)

    for root in roots:
        for variant in variants:
            variant_path = Path(variant)
            basename = variant_path.name

            # Полный относительный путь из .mesh или его DDS-вариант.
            candidates.append(root / variant)

            # Если Texture root указывает прямо на папку textures, а ref уже
            # начинается с textures/..., надо также пробовать путь без первого
            # компонента. Если Texture root указывает на rq_extracted/client —
            # наоборот, добавляем root/textures/...
            if variant.lower().startswith("textures/"):
                stripped = variant[len("textures/") :]
                candidates.append(root / stripped)
                candidates.append(root / "textures" / stripped)
            else:
                candidates.append(root / "textures" / variant)

            # Standalone / asset-pack случаи: texture файлы часто лежат рядом с
            # .mesh или внутри assets/textures без папок landscape/buildings.
            candidates.append(root / basename)
            candidates.append(root / "textures" / basename)
            candidates.append(root / "assets" / "textures" / basename)

    unique: list[Path] = []
    seen: set[str] = set()
    for item in candidates:
        key = str(item).replace("\\", "/").lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique



def _find_texture_file(texture_path: str, mesh_path: Path, texture_root: str = "") -> Path | None:
    if not str(texture_path or "").strip():
        return None

    candidates = _texture_candidates(texture_path, mesh_path, texture_root)
    for candidate in candidates:
        resolved = _case_insensitive_existing_path(candidate)
        if resolved is not None:
            return resolved

    # Последний, но всё ещё строгий fallback: ищем только точные имена файлов
    # из набора допустимых вариантов. Это не хардкод по моделям, а поддержка
    # разных layout-ов распаковки: полный client/rq_extracted, standalone mesh
    # рядом с текстурами, и asset-pack с assets/textures/mesh__textures__...
    wanted = {Path(v).name.lower() for v in _texture_ref_variants(texture_path)}
    if not wanted:
        return None

    normalized_parents = {Path(v).parent.as_posix().lower() for v in _texture_ref_variants(texture_path)}
    search_dirs: list[Path] = []

    def add_dir(folder: Path) -> None:
        try:
            key = str(folder.resolve()).lower()
        except Exception:
            key = str(folder).lower()
        for existing in search_dirs:
            try:
                existing_key = str(existing.resolve()).lower()
            except Exception:
                existing_key = str(existing).lower()
            if existing_key == key:
                return
        search_dirs.append(folder)

    for root in _texture_roots(mesh_path, texture_root):
        add_dir(root)
        add_dir(root / "textures")
        add_dir(root / "assets" / "textures")
        add_dir(root.parent / "textures")
        add_dir(root.parent / "assets" / "textures")

        for parent_ref in normalized_parents:
            if not parent_ref or parent_ref == ".":
                continue
            add_dir(root / parent_ref)
            if parent_ref.startswith("textures/"):
                stripped = parent_ref[len("textures/") :]
                add_dir(root / stripped)
                add_dir(root / "textures" / stripped)
            else:
                add_dir(root / "textures" / parent_ref)

    for folder in search_dirs:
        if not folder.is_dir():
            continue
        try:
            for child in folder.iterdir():
                if child.is_file() and child.name.lower() in wanted:
                    return child
        except Exception:
            continue

    # Рекурсивный поиск оставлен только для очевидных texture-папок, чтобы не
    # прочёсывать весь rq_extracted/client при каждом отсутствующем файле.
    recursive_roots: list[Path] = []
    for root in _texture_roots(mesh_path, texture_root):
        texture_like_dirs = [root / "textures", root / "assets" / "textures"]
        if root.name.lower() in {"textures", "texture", "assets"}:
            texture_like_dirs.append(root)
        for folder in texture_like_dirs:
            if folder.is_dir():
                try:
                    key = str(folder.resolve()).lower()
                except Exception:
                    key = str(folder).lower()
                if all(str(existing.resolve()).lower() != key for existing in recursive_roots if existing.exists()):
                    recursive_roots.append(folder)

    for folder in recursive_roots:
        try:
            for child in folder.rglob("*"):
                if child.is_file() and child.name.lower() in wanted:
                    return child
        except Exception:
            continue

    return None

@dataclass
class _DecodedDDS:
    width: int
    height: int
    fourcc: bytes
    compressed: bytes


def _parse_dds(data: bytes) -> _DecodedDDS:
    if len(data) < DDS_HEADER_SIZE or data[:4] != DDS_MAGIC:
        raise ValueError("not a DDS file")
    height = struct.unpack_from("<I", data, 12)[0]
    width = struct.unpack_from("<I", data, 16)[0]
    fourcc = data[84:88]
    if fourcc not in DDS_BLOCK_BYTES:
        raise ValueError(f"unsupported DDS fourcc: {fourcc!r}")
    blocks_w = max(1, (width + 3) // 4)
    blocks_h = max(1, (height + 3) // 4)
    expected = blocks_w * blocks_h * DDS_BLOCK_BYTES[fourcc]
    compressed = data[DDS_HEADER_SIZE : DDS_HEADER_SIZE + expected]
    if len(compressed) < expected:
        raise ValueError("DDS payload is truncated")
    return _DecodedDDS(width=width, height=height, fourcc=fourcc, compressed=compressed)


def _decode_dxt_color_block(block: bytes) -> list[tuple[int, int, int]]:
    c0, c1 = struct.unpack_from("<HH", block, 0)
    bits = struct.unpack_from("<I", block, 4)[0]

    def rgb565(value: int) -> tuple[int, int, int]:
        r = ((value >> 11) & 0x1F) * 255 // 31
        g = ((value >> 5) & 0x3F) * 255 // 63
        b = (value & 0x1F) * 255 // 31
        return r, g, b

    colors = [rgb565(c0), rgb565(c1)]
    if c0 > c1:
        colors.extend(
            [
                tuple((2 * colors[0][i] + colors[1][i]) // 3 for i in range(3)),
                tuple((colors[0][i] + 2 * colors[1][i]) // 3 for i in range(3)),
            ]
        )
    else:
        colors.extend(
            [
                tuple((colors[0][i] + colors[1][i]) // 2 for i in range(3)),
                (0, 0, 0),
            ]
        )

    pixels: list[tuple[int, int, int]] = []
    for py in range(4):
        for px in range(4):
            idx = (bits >> (2 * (py * 4 + px))) & 0x3
            pixels.append(colors[idx])
    return pixels


def _decode_dxt5_alpha_block(block: bytes) -> list[int]:
    a0 = block[0]
    a1 = block[1]
    if a0 > a1:
        alphas = [a0, a1] + [((7 - i) * a0 + i * a1) // 7 for i in range(1, 7)]
    else:
        alphas = [a0, a1] + [((5 - i) * a0 + i * a1) // 5 for i in range(1, 5)] + [0, 255]
    bits = int.from_bytes(block[2:8], "little")
    return [alphas[(bits >> (3 * i)) & 0x7] for i in range(16)]


def _decompress_dxt1(width: int, height: int, compressed: bytes) -> bytes:
    blocks_w = max(1, (width + 3) // 4)
    blocks_h = max(1, (height + 3) // 4)
    rgba = bytearray(width * height * 4)
    offset = 0
    for by in range(blocks_h):
        for bx in range(blocks_w):
            block = compressed[offset : offset + 8]
            offset += 8
            pixels = _decode_dxt_color_block(block)
            for py in range(4):
                for px in range(4):
                    x = bx * 4 + px
                    y = by * 4 + py
                    if x >= width or y >= height:
                        continue
                    r, g, b = pixels[py * 4 + px]
                    i = (y * width + x) * 4
                    rgba[i : i + 4] = bytes((r, g, b, 255))
    return bytes(rgba)


def _decompress_dxt5(width: int, height: int, compressed: bytes) -> bytes:
    blocks_w = max(1, (width + 3) // 4)
    blocks_h = max(1, (height + 3) // 4)
    rgba = bytearray(width * height * 4)
    offset = 0
    for by in range(blocks_h):
        for bx in range(blocks_w):
            alpha_block = compressed[offset : offset + 8]
            color_block = compressed[offset + 8 : offset + 16]
            offset += 16
            alphas = _decode_dxt5_alpha_block(alpha_block)
            colors = _decode_dxt_color_block(color_block)
            for py in range(4):
                for px in range(4):
                    x = bx * 4 + px
                    y = by * 4 + py
                    if x >= width or y >= height:
                        continue
                    r, g, b = colors[py * 4 + px]
                    a = alphas[py * 4 + px]
                    i = (y * width + x) * 4
                    rgba[i : i + 4] = bytes((r, g, b, a))
    return bytes(rgba)


def _flip_rgba_vertical(width: int, height: int, rgba: bytes) -> bytes:
    row_bytes = width * 4
    out = bytearray(len(rgba))
    for y in range(height):
        src = (height - 1 - y) * row_bytes
        out[y * row_bytes : (y + 1) * row_bytes] = rgba[src : src + row_bytes]
    return bytes(out)


def _is_packed_diff_spec_texture(path: str | Path) -> bool:
    name = Path(str(path).replace("\\", "/")).name.lower()
    if not name.endswith(".dds"):
        return False

    # У RQ alpha в *_diff__*_spec_dxt*.dds и в чистых *_spec_dxt*.dds обычно
    # служебный spec/mask-канал, а не прозрачность материала. Если его подключить
    # к Alpha в Blender, камни/стены становятся полупрозрачными или дырявыми.
    if "__" in name and "_diff" in name and "_spec" in name:
        return True
    return bool(re.search(r"_spec(?:_dxt[15])?\.dds$", name))


def _force_image_alpha_opaque(image: bpy.types.Image) -> bpy.types.Image:
    try:
        image.alpha_mode = "NONE"
    except Exception:
        pass

    try:
        width = int(image.size[0])
        height = int(image.size[1])
        if width <= 0 or height <= 0:
            return image

        from array import array

        pixels = array("f", [0.0]) * (width * height * 4)
        image.pixels.foreach_get(pixels)
        changed = False
        for i in range(3, len(pixels), 4):
            if pixels[i] != 1.0:
                pixels[i] = 1.0
                changed = True
        if changed:
            image.pixels.foreach_set(pixels)
            image.update()
    except Exception:
        pass
    return image


def _image_has_meaningful_alpha(image: bpy.types.Image, allow_soft_alpha: bool = False) -> bool:
    try:
        width = int(image.size[0])
        height = int(image.size[1])
        channels = int(getattr(image, "channels", 4) or 4)
        if width <= 0 or height <= 0 or channels < 4:
            return False

        from array import array

        pixels = array("f", [0.0]) * (width * height * channels)
        image.pixels.foreach_get(pixels)

        total = 0
        near_zero = 0
        near_one = 0
        middle = 0
        min_alpha = 1.0
        max_alpha = 0.0

        for i in range(3, len(pixels), channels):
            value = float(pixels[i])
            total += 1
            if value < min_alpha:
                min_alpha = value
            if value > max_alpha:
                max_alpha = value
            if value <= 0.05:
                near_zero += 1
            elif value >= 0.95:
                near_one += 1
            else:
                middle += 1

        if total <= 0 or min_alpha >= 0.995:
            return False

        # Soft alpha is allowed only when the material/texture name explicitly
        # says that this is a transparent thing, for example glass/window/decal.
        # A lot of RQ DXT5 diffuse textures store spec/gloss/lighting data in
        # alpha. Those alpha channels are real data, but they are not material
        # opacity and must not be connected to Principled Alpha.
        if allow_soft_alpha:
            return max_alpha > 0.005

        zero_ratio = near_zero / total
        one_ratio = near_one / total
        middle_ratio = middle / total

        # Real cutout/decal opacity normally has a visible transparent part and
        # a visible opaque part. Spec/gloss channels usually look like grayscale
        # masks with mostly middle values and no solid 0/1 opacity regions.
        if zero_ratio >= 0.003 and one_ratio >= 0.02:
            return True

        # Very soft masks can still have a transparent background and no large
        # fully-opaque region. Keep this strict so ordinary DXT5 spec data does
        # not make whole buildings semi-transparent.
        if zero_ratio >= 0.02 and middle_ratio >= 0.02 and max_alpha >= 0.35:
            return True

        return False
    except Exception:
        return False


def _texture_name_suggests_real_alpha(texture_path: str, texture_file: str | Path | None = None) -> bool:
    names: list[str] = []
    for value in (texture_path, str(texture_file or "")):
        if not value:
            continue
        path = Path(value.replace("\\", "/"))
        names.append(path.stem.lower())
        names.append(path.name.lower())

    text = " ".join(names)
    if not text:
        return False

    # These are material/texture roles, not mesh names. They describe cases
    # where alpha is commonly actual opacity in RQ assets. Ordinary *_dxt5.dds
    # diffuse textures are deliberately not treated as transparent just because
    # an alpha channel exists.
    alpha_words = (
        "alpha",
        "decal",
        "glass",
        "window",
        "transparent",
        "transp",
        "opacity",
        "banner",
        "flag",
        "curtain",
        "cloth",
        "leaf",
        "leaves",
        "foliage",
        "branch",
        "bush",
        "grass",
        "plant",
        "flower",
        "vine",
        "smoke",
        "cloud",
        "glow",
        "flare",
    )
    return any(word in text for word in alpha_words)


def _load_dds_as_blender_image(path: Path, force_opaque: bool = False) -> bpy.types.Image:
    resolved = path.resolve()

    parsed = _parse_dds(path.read_bytes())
    if parsed.fourcc == b"DXT1":
        rgba = _decompress_dxt1(parsed.width, parsed.height, parsed.compressed)
    elif parsed.fourcc == b"DXT5":
        rgba = _decompress_dxt5(parsed.width, parsed.height, parsed.compressed)
    else:
        raise ValueError(f"unsupported DDS fourcc: {parsed.fourcc!r}")

    rgba = bytearray(_flip_rgba_vertical(parsed.width, parsed.height, rgba))
    if force_opaque:
        for i in range(3, len(rgba), 4):
            rgba[i] = 255

    # Не переиспользуем старый datablock, если он уже был создан прошлой
    # версией аддона с принудительно стёртой alpha. Иначе после обновления
    # прозрачные decals/windows могут всё равно оставаться чёрными.
    image = bpy.data.images.new(path.name, width=parsed.width, height=parsed.height, alpha=not force_opaque)
    image.filepath = str(resolved)

    from array import array

    pixels = array("f", (value / 255.0 for value in rgba))
    image.pixels.foreach_set(pixels)
    image.update()
    if force_opaque:
        image[TRANSPARENT_ALPHA_PROP] = False
        return _force_image_alpha_opaque(image)
    try:
        image.alpha_mode = "STRAIGHT"
    except Exception:
        pass
    image[TRANSPARENT_ALPHA_PROP] = _image_has_meaningful_alpha(image)
    return image


def _load_texture_as_blender_image(path: Path, force_opaque: bool = False) -> bpy.types.Image:
    # DDS у RQ часто DXT1/DXT5. Для них используем свой декодер, чтобы
    # одинаково обрабатывать alpha в разных версиях Blender и не зависеть от
    # старых image datablocks, оставшихся после предыдущего импорта.
    if path.suffix.lower() == ".dds":
        try:
            return _load_dds_as_blender_image(path, force_opaque=force_opaque)
        except Exception:
            image = bpy.data.images.load(str(path), check_existing=not force_opaque)
            if force_opaque:
                image[TRANSPARENT_ALPHA_PROP] = False
                return _force_image_alpha_opaque(image)
            try:
                image.alpha_mode = "STRAIGHT"
            except Exception:
                pass
            image[TRANSPARENT_ALPHA_PROP] = _image_has_meaningful_alpha(image)
            return image

    image = bpy.data.images.load(str(path), check_existing=not force_opaque)
    if force_opaque:
        image[TRANSPARENT_ALPHA_PROP] = False
        return _force_image_alpha_opaque(image)
    try:
        image.alpha_mode = "STRAIGHT"
    except Exception:
        pass
    image[TRANSPARENT_ALPHA_PROP] = _image_has_meaningful_alpha(image)
    return image


def _make_material(texture_path: str, mesh_path: Path, texture_root: str = "") -> bpy.types.Material:
    mat_name = _safe_name(texture_path, "rq_material")
    mat = bpy.data.materials.new(mat_name)
    mat[TEXTURE_PATH_PROP] = texture_path
    mat.use_nodes = True

    texture_file = _find_texture_file(texture_path, mesh_path, texture_root)
    if texture_file is None:
        mat[TRANSPARENT_ALPHA_PROP] = False
        mat["rq_alpha_reason"] = "no_texture"
        return mat
    mat[RESOLVED_TEXTURE_PATH_PROP] = str(texture_file)

    # Важно: у Royal Quest DXT5 alpha очень часто НЕ является прозрачностью
    # материала. В alpha у обычных diffuse-текстур может лежать служебная
    # spec/gloss/mask информация. Пример: bookcase_05.mesh ->
    # textures/levels/Library_01/library_lev_01.tga, а на диске найден
    # library_lev_01_dxt5.dds; его alpha не должен подключаться к BSDF Alpha,
    # иначе весь шкаф становится полупрозрачным.
    #
    # Поэтому alpha включается только для текстур/материалов с прозрачной ролью
    # в имени: alpha/decal/glass/window/leaves/foliage/etc. Наличие alpha-канала
    # в DXT5 само по себе больше не достаточно.
    force_opaque = _is_packed_diff_spec_texture(texture_file)

    try:
        image = _load_texture_as_blender_image(texture_file, force_opaque=force_opaque)
    except Exception as exc:
        mat[RESOLVED_TEXTURE_PATH_PROP] = f"LOAD_FAILED: {texture_file} :: {exc}"
        mat[TRANSPARENT_ALPHA_PROP] = False
        mat["rq_alpha_reason"] = "load_failed"
        return mat

    name_suggests_alpha = _texture_name_suggests_real_alpha(texture_path, texture_file)
    has_named_alpha = False if force_opaque else (
        name_suggests_alpha and _image_has_meaningful_alpha(image, allow_soft_alpha=True)
    )
    use_alpha = bool(has_named_alpha)

    if force_opaque:
        alpha_reason = "opaque_spec_or_packed_spec"
    elif has_named_alpha:
        alpha_reason = "named_alpha_texture"
    elif name_suggests_alpha:
        alpha_reason = "named_but_no_meaningful_alpha"
    else:
        alpha_reason = "opaque_dxt_alpha_treated_as_data"

    mat[TRANSPARENT_ALPHA_PROP] = bool(use_alpha)
    mat["rq_alpha_reason"] = alpha_reason

    try:
        nodes = mat.node_tree.nodes
        bsdf = nodes.get("Principled BSDF")
        tex = nodes.new(type="ShaderNodeTexImage")
        tex.image = image
        try:
            tex.extension = "REPEAT"
        except Exception:
            pass
        if bsdf is not None:
            color_output = tex.outputs.get("Color")
            base_color_input = bsdf.inputs.get("Base Color")
            if color_output is not None and base_color_input is not None:
                mat.node_tree.links.new(color_output, base_color_input)

            alpha_input = bsdf.inputs.get("Alpha")
            alpha_output = tex.outputs.get("Alpha")
            if alpha_input is not None:
                alpha_input.default_value = 1.0
                if use_alpha and alpha_output is not None:
                    mat.node_tree.links.new(alpha_output, alpha_input)

            if use_alpha:
                try:
                    image.alpha_mode = "STRAIGHT"
                except Exception:
                    pass
                try:
                    mat.blend_method = "BLEND"
                except Exception:
                    pass
                try:
                    mat.surface_render_method = "BLENDED"
                except Exception:
                    pass
                try:
                    mat.use_screen_refraction = False
                except Exception:
                    pass
                try:
                    mat.show_transparent_back = True
                except Exception:
                    pass
                try:
                    mat.diffuse_color = (1.0, 1.0, 1.0, 0.5)
                except Exception:
                    pass
            else:
                try:
                    mat.blend_method = "OPAQUE"
                except Exception:
                    pass
                try:
                    mat.surface_render_method = "OPAQUE"
                except Exception:
                    pass
                try:
                    mat.use_screen_refraction = False
                except Exception:
                    pass
                try:
                    mat.show_transparent_back = False
                except Exception:
                    pass
                try:
                    mat.diffuse_color = (1.0, 1.0, 1.0, 1.0)
                except Exception:
                    pass
    except Exception:
        pass
    return mat

def _build_import_mesh(mesh_data: MeshData, texture_root: str = "", flip_v: bool = True) -> bpy.types.Object:
    vertices: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int]] = []
    face_texture_indices: list[int] = []
    loop_uvs: list[tuple[float, float]] = []
    metadata_chunks: list[dict[str, Any]] = []

    for chunk_index, chunk in enumerate(mesh_data.chunks):
        start_vertex = len(vertices)
        start_face = len(faces)
        vertices.extend(chunk.vertices)

        for tri_pos in range(0, len(chunk.indices) - 2, 3):
            i0 = int(chunk.indices[tri_pos])
            i1 = int(chunk.indices[tri_pos + 1])
            i2 = int(chunk.indices[tri_pos + 2])
            if i0 >= chunk.vertex_count or i1 >= chunk.vertex_count or i2 >= chunk.vertex_count:
                continue

            faces.append((start_vertex + i0, start_vertex + i1, start_vertex + i2))
            face_texture_indices.append(chunk.texture_index)

            # Важный момент: .mesh хранит UV per-vertex, но Blender хранит UV
            # per-loop. Для повторяющихся текстур это нужно использовать:
            # если один треугольник пересекает seam 0/1/2/3/4, его loop UV
            # надо сдвинуть на целое число тайлов, иначе в UV Editor и на
            # материале появляется длинная диагональ через всю развёртку.
            # Это не хардкод по модели, а общая обработка wrapped UV.
            loop_uvs.extend(
                _unwrap_triangle_uvs_for_blender(
                    [chunk.uvs[i0], chunk.uvs[i1], chunk.uvs[i2]],
                    flip_v,
                )
            )

        metadata_chunks.append(
            {
                "chunk_index": chunk_index,
                "start_vertex": start_vertex,
                "vertex_count": chunk.vertex_count,
                "start_face": start_face,
                "face_count": len(faces) - start_face,
                "stride": chunk.stride,
                "texture_index": chunk.texture_index,
                "uv_scale": chunk.uv_scale,
                "geom_offset": chunk.geom_offset,
                "chunk_size": chunk.chunk_size,
                "raw_index_count": chunk.raw_index_count,
                "primary_index_count": chunk.primary_index_count,
                "primary_index_data_offset": chunk.primary_index_data_offset,
                "tail_index_count": chunk.tail_index_count,
                "tail_index_data_offset": chunk.tail_index_data_offset,
            }
        )

    blend_mesh = bpy.data.meshes.new(mesh_data.path.stem)
    blend_mesh.from_pydata(vertices, [], faces)
    blend_mesh.update()

    if faces:
        uv_layer = blend_mesh.uv_layers.new(name="RQ_UV")
        uv_cursor = 0
        for poly in blend_mesh.polygons:
            for loop_index in poly.loop_indices:
                if uv_cursor < len(loop_uvs):
                    uv_layer.data[loop_index].uv = loop_uvs[uv_cursor]
                uv_cursor += 1
        blend_mesh.uv_layers.active = uv_layer
        uv_layer.active_render = True

    obj = bpy.data.objects.new(mesh_data.path.stem, blend_mesh)
    bpy.context.collection.objects.link(obj)

    texture_count = max(len(mesh_data.textures), max(face_texture_indices, default=-1) + 1)
    for i in range(texture_count):
        texture_path = mesh_data.textures[i] if i < len(mesh_data.textures) else f"material_{i}"
        obj.data.materials.append(_make_material(texture_path, mesh_data.path, texture_root))

    for poly_index, poly in enumerate(blend_mesh.polygons):
        texture_index = face_texture_indices[poly_index] if poly_index < len(face_texture_indices) else 0
        poly.material_index = min(max(int(texture_index), 0), max(0, len(obj.data.materials) - 1))

    metadata = {
        "format": "rq_mesh_blender_addon_v1",
        "source_path": str(mesh_data.path),
        "file_size": mesh_data.file_size,
        "declared_size": mesh_data.declared_size,
        "textures": mesh_data.textures,
        "animblock_path": mesh_data.animblock_path,
        "bone_palette": mesh_data.bone_palette,
        "uv_flip_v": bool(flip_v),
        "uv_encoding": "signed_int16_div_16384",
        "uv_loop_unwrap": "repeat_period_1_conservative",
        "chunks": metadata_chunks,
    }
    obj[META_PROP] = json.dumps(metadata, ensure_ascii=False)
    obj[SOURCE_PATH_PROP] = str(mesh_data.path)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    return obj

# -----------------------------------------------------------------------------
# Export helpers: safe patching of original .mesh, and minimal new .mesh writer.
# -----------------------------------------------------------------------------


def _material_texture_path(material: bpy.types.Material | None, fallback_index: int) -> str:
    if material is not None and TEXTURE_PATH_PROP in material:
        return str(material[TEXTURE_PATH_PROP]).replace("\\", "/")
    if material is not None:
        name = material.name.split(".")[0]
        return name or f"material_{fallback_index}.tga"
    return f"material_{fallback_index}.tga"


def _triangulated_mesh_from_object(context: bpy.types.Context, obj: bpy.types.Object, apply_modifiers: bool) -> bpy.types.Mesh:
    if obj.type != "MESH":
        raise ValueError("Для экспорта должен быть выбран Mesh-объект")

    if apply_modifiers:
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = bpy.data.meshes.new_from_object(eval_obj, depsgraph=depsgraph, preserve_all_data_layers=True)
    else:
        mesh = obj.data.copy()

    if any(len(poly.vertices) != 3 for poly in mesh.polygons):
        if bmesh is None:
            bpy.data.meshes.remove(mesh)
            raise ValueError("В модели есть не треугольные полигоны, а bmesh недоступен")
        bm = bmesh.new()
        bm.from_mesh(mesh)
        faces = [face for face in bm.faces if len(face.verts) > 3]
        if faces:
            bmesh.ops.triangulate(bm, faces=faces)
        bm.to_mesh(mesh)
        bm.free()
        mesh.update()
    return mesh


def _face_loop_uv(mesh: bpy.types.Mesh, polygon: bpy.types.MeshPolygon, loop_position: int) -> tuple[float, float]:
    if not mesh.uv_layers.active:
        return (0.0, 0.0)
    loop_index = polygon.loop_indices[loop_position]
    uv = mesh.uv_layers.active.data[loop_index].uv
    return (float(uv.x), float(uv.y))


def _face_loop_normal(mesh: bpy.types.Mesh, polygon: bpy.types.MeshPolygon, loop_position: int) -> tuple[float, float, float]:
    try:
        loop = mesh.loops[polygon.loop_indices[loop_position]]
        normal = loop.normal
        return (float(normal.x), float(normal.y), float(normal.z))
    except Exception:
        normal = polygon.normal
        return (float(normal.x), float(normal.y), float(normal.z))


def _load_metadata(obj: bpy.types.Object) -> dict[str, Any] | None:
    if META_PROP not in obj:
        return None
    try:
        loaded = json.loads(str(obj[META_PROP]))
    except Exception:
        return None
    if not isinstance(loaded, dict) or loaded.get("format") != "rq_mesh_blender_addon_v1":
        return None
    return loaded


def _object_matrix_for_export(obj: bpy.types.Object, apply_object_transform: bool) -> Matrix:
    return obj.matrix_world.copy() if apply_object_transform else Matrix.Identity(4)


def _patch_template_export(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    out_path: Path,
    metadata: dict[str, Any],
    apply_modifiers: bool,
    apply_object_transform: bool,
) -> tuple[bool, str]:
    source_path = Path(str(metadata.get("source_path") or obj.get(SOURCE_PATH_PROP, "")))
    if not source_path.exists():
        return False, "исходный .mesh не найден, будет создан минимальный файл"

    chunks_meta = metadata.get("chunks")
    if not isinstance(chunks_meta, list) or not chunks_meta:
        return False, "нет данных о чанках исходного файла"

    uv_flip_v = bool(metadata.get("uv_flip_v", True))

    mesh = _triangulated_mesh_from_object(context, obj, apply_modifiers)
    transform = _object_matrix_for_export(obj, apply_object_transform)
    try:
        data = bytearray(source_path.read_bytes())
        _declared_size, _section_count, sections = parse_sections(bytes(data))
        geom_section = section_by_id(sections, 3)
        if geom_section is None:
            return False, "в исходном файле нет секции геометрии"

        mesh.calc_loop_triangles()
        mesh.update(calc_edges=False)

        for chunk in chunks_meta:
            start_vertex = int(chunk["start_vertex"])
            vertex_count = int(chunk["vertex_count"])
            start_face = int(chunk["start_face"])
            face_count = int(chunk["face_count"])
            stride = int(chunk["stride"])
            uv_scale = float(chunk.get("uv_scale", 4.0) or 4.0)
            geom_offset = int(chunk["geom_offset"])
            primary_index_count = int(chunk.get("primary_index_count", 0))
            primary_index_data_offset = int(chunk.get("primary_index_data_offset", 0))
            tail_index_count = int(chunk.get("tail_index_count", 0))
            tail_index_data_offset = int(chunk.get("tail_index_data_offset", 0))

            if start_vertex + vertex_count > len(mesh.vertices):
                return False, "количество вершин изменено; template patch невозможен"
            if start_face + face_count > len(mesh.polygons):
                return False, "количество полигонов изменено; template patch невозможен"
            if face_count * 3 != primary_index_count + tail_index_count:
                return False, "число индексов чанка не совпадает с исходным"

            chunk_file_offset = geom_section.offset + geom_offset
            vertex_start = chunk_file_offset + CHUNK_HEADER

            for local_index in range(vertex_count):
                vertex = mesh.vertices[start_vertex + local_index]
                co = transform @ vertex.co
                base = vertex_start + local_index * stride
                if base + 12 > len(data):
                    return False, "выход за границы файла при записи вершин"
                struct.pack_into("<3f", data, base, float(co.x), float(co.y), float(co.z))
                _write_vertex_normal(data, base, stride, vertex.normal)

            indices: list[int] = []
            per_vertex_uv: dict[int, tuple[float, float]] = {}
            for face_index in range(start_face, start_face + face_count):
                polygon = mesh.polygons[face_index]
                if len(polygon.vertices) != 3:
                    return False, "после триангуляции найден не треугольный полигон"
                for loop_pos, vertex_index in enumerate(polygon.vertices):
                    local_index = int(vertex_index) - start_vertex
                    if local_index < 0 or local_index >= vertex_count:
                        return False, "вершины чанков перемешаны; template patch невозможен"
                    indices.append(local_index)
                    blender_uv = _face_loop_uv(mesh, polygon, loop_pos)
                    per_vertex_uv[local_index] = _blender_uv_to_rq(blender_uv, uv_flip_v)

            for local_index, uv in per_vertex_uv.items():
                base = vertex_start + local_index * stride
                _write_vertex_uv(data, base, stride, uv, uv_scale)

            if len(indices) != primary_index_count + tail_index_count:
                return False, "число индексов после экспорта не совпало с исходным"
            if max(indices, default=0) > 65535:
                return False, "индекс вершины больше 65535"

            primary = indices[:primary_index_count]
            if primary:
                index_abs = chunk_file_offset + primary_index_data_offset
                if index_abs + len(primary) * 2 > len(data):
                    return False, "выход за границы файла при записи индексов"
                struct.pack_into(f"<{len(primary)}H", data, index_abs, *primary)

            if tail_index_count:
                tail = indices[primary_index_count:]
                tail_abs = chunk_file_offset + tail_index_data_offset
                if tail_abs + len(tail) * 2 > len(data):
                    return False, "выход за границы файла при записи tail-индексов"
                struct.pack_into(f"<{len(tail)}H", data, tail_abs, *tail)

        out_path.write_bytes(bytes(data))
        return True, "экспорт выполнен через безопасное обновление исходного шаблона"
    finally:
        bpy.data.meshes.remove(mesh)


def _build_texture_section(texture_paths: list[str]) -> bytes:
    raw = bytearray()
    raw += struct.pack("<I", len(texture_paths))
    for path in texture_paths:
        name = Path(path.replace("\\", "/")).stem
        for ch in name:
            raw += struct.pack("<H", ord(ch))
        raw += struct.pack("<H", 0)
        raw += path.replace("\\", "/").encode("ascii", errors="replace") + b"\x00"
    return bytes(raw)


def _build_geometry_chunk(
    vertices: list[tuple[Vector, tuple[float, float], tuple[float, float, float]]],
    indices: list[int],
    uv_scale: float = 4.0,
) -> bytes:
    if len(vertices) > 65535:
        raise ValueError("Один .mesh chunk не может иметь больше 65535 вершин")
    if len(indices) % 3 != 0:
        raise ValueError("Индексы чанка не кратны трём")

    raw = bytearray()
    raw += struct.pack("<III", 0, len(vertices), 20)
    for co, uv, normal in vertices:
        raw += struct.pack("<3f", float(co.x), float(co.y), float(co.z))
        scale_value = float(uv_scale)
        if scale_value <= 0.0:
            scale_value = 4.0
        u = max(0, min(65535, int(round(float(uv[0]) * 65535.0 / scale_value))))
        v = max(0, min(65535, int(round(float(uv[1]) * 65535.0 / scale_value))))
        raw += struct.pack("<HHI", u, v, _encode_packed_normal(normal))

    # The .mesh geometry header stores triangle count here. The index buffer
    # itself still contains 3 uint16 indices per triangle.
    raw += struct.pack("<I", len(indices) // 3)
    raw += struct.pack(f"<{len(indices)}H", *indices)
    return bytes(raw)


def _submesh_header(first_chunk_rel: int, second_chunk_rel: int | None = None) -> bytes:
    raw = bytearray(0x40)
    put_u32(raw, 0x08, 5)
    put_u32(raw, 0x10, 0x30)
    put_u32(raw, 0x14, 1)
    put_u32(raw, 0x18, 0)
    put_u32(raw, 0x1C, 0xFFFFFFFF)
    put_u32(raw, 0x20, 0x54)
    put_u32(raw, 0x24, 2)
    put_u32(raw, 0x28, first_chunk_rel)
    put_u32(raw, 0x2C, 4)
    if second_chunk_rel is not None:
        put_u32(raw, 0x30, second_chunk_rel)
        put_u32(raw, 0x34, 4)
    return bytes(raw)


def _build_geometry_section(chunks: list[bytes]) -> bytes:
    raw = bytearray()
    for chunk in chunks:
        base = len(raw)
        raw += _submesh_header(0x40)
        raw += chunk
        while len(raw) % 4:
            raw += b"\x00"
        # Keep base variable intentionally: scanner finds each header by its byte offset.
        _ = base
    return bytes(raw)


def _build_minimal_mesh_file(texture_paths: list[str], geometry_chunks: list[bytes]) -> bytes:
    texture_section = _build_texture_section(texture_paths)
    geometry_section = _build_geometry_section(geometry_chunks)
    section_count = 2
    header_size = 8 + section_count * 8
    texture_offset = header_size
    geometry_offset = texture_offset + len(texture_section)
    declared_size = geometry_offset + len(geometry_section)
    raw = bytearray()
    raw += struct.pack("<II", declared_size, section_count)
    raw += struct.pack("<II", 2, texture_offset)
    raw += struct.pack("<II", 3, geometry_offset)
    raw += texture_section
    raw += geometry_section
    return bytes(raw)


def _minimal_export(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    out_path: Path,
    apply_modifiers: bool,
    apply_object_transform: bool,
) -> tuple[bool, str]:
    mesh = _triangulated_mesh_from_object(context, obj, apply_modifiers)
    transform = _object_matrix_for_export(obj, apply_object_transform)
    metadata = _load_metadata(obj)
    uv_flip_v = bool(metadata.get("uv_flip_v", True)) if metadata is not None else True
    uv_scale = 4.0
    if metadata is not None:
        chunks_meta = metadata.get("chunks")
        if isinstance(chunks_meta, list) and chunks_meta:
            try:
                uv_scale = float(chunks_meta[0].get("uv_scale", 4.0) or 4.0)
            except Exception:
                uv_scale = 4.0
    try:
        mesh.calc_loop_triangles()
        mesh.update(calc_edges=False)
        material_count = max(1, len(obj.data.materials))
        texture_paths = [
            _material_texture_path(obj.data.materials[i] if i < len(obj.data.materials) else None, i)
            for i in range(material_count)
        ]

        chunk_bytes: list[bytes] = []
        chunk_texture_paths: list[str] = []
        for material_index in range(material_count):
            chunk_vertices: list[tuple[Vector, tuple[float, float], tuple[float, float, float]]] = []
            chunk_indices: list[int] = []
            vertex_map: dict[tuple[int, int, int, int], int] = {}

            def flush() -> None:
                nonlocal chunk_vertices, chunk_indices, vertex_map
                if chunk_vertices and chunk_indices:
                    chunk_bytes.append(_build_geometry_chunk(chunk_vertices, chunk_indices, uv_scale))
                    chunk_texture_paths.append(texture_paths[material_index])
                chunk_vertices = []
                chunk_indices = []
                vertex_map = {}

            for polygon in mesh.polygons:
                poly_mat = min(max(int(polygon.material_index), 0), material_count - 1)
                if poly_mat != material_index:
                    continue
                local_indices: list[int] = []
                for loop_pos, vertex_index in enumerate(polygon.vertices):
                    blender_uv = _face_loop_uv(mesh, polygon, loop_pos)
                    rq_uv = _blender_uv_to_rq(blender_uv, uv_flip_v)
                    uv_key = (int(round(rq_uv[0] * 100000.0)), int(round(rq_uv[1] * 100000.0)))
                    key = (int(vertex_index), uv_key[0], uv_key[1], loop_pos)
                    if key not in vertex_map:
                        if len(chunk_vertices) >= 65535:
                            flush()
                        vertex = mesh.vertices[int(vertex_index)]
                        co = transform @ vertex.co
                        normal = _face_loop_normal(mesh, polygon, loop_pos)
                        vertex_map[key] = len(chunk_vertices)
                        chunk_vertices.append((co, rq_uv, normal))
                    local_indices.append(vertex_map[key])
                if len(local_indices) == 3:
                    chunk_indices.extend(local_indices)
            flush()

        if not chunk_bytes:
            raise ValueError("Нет треугольников для экспорта")

        out_path.write_bytes(_build_minimal_mesh_file(chunk_texture_paths, chunk_bytes))
        return True, "создан минимальный .mesh; для игры лучше экспортировать поверх импортированного шаблона"
    finally:
        bpy.data.meshes.remove(mesh)


# -----------------------------------------------------------------------------
# Blender operators.
# -----------------------------------------------------------------------------



class RQMeshAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_PREFERENCES_ID

    drag_drop_texture_root: StringProperty(
        name="Drag-and-drop Texture root",
        description="Папка с распакованными textures для импорта перетаскиванием. Если пусто, аддон ищет textures рядом с .mesh и выше по папкам",
        default="",
        subtype="DIR_PATH",
    )
    drag_drop_flip_v: BoolProperty(
        name="Drag-and-drop Flip V",
        description="Перевернуть V-координату UV при импорте через drag-and-drop",
        default=True,
    )
    drag_drop_uv_scale_mode: EnumProperty(
        name="Drag-and-drop UV scale",
        description="Как декодировать 16-битные UV при импорте через drag-and-drop",
        items=UV_SCALE_MODE_ITEMS,
        default="AUTO",
    )
    drag_drop_rq_z_rotation_fix: BoolProperty(
        name="Drag-and-drop RQ Z 180° correction",
        description="Разворачивать импортированный через drag-and-drop объект вокруг Blender Z на 180 градусов",
        default=True,
    )

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout
        layout.label(text="Настройки используются только для drag-and-drop .mesh в окно Blender.")
        layout.prop(self, "drag_drop_texture_root")
        layout.prop(self, "drag_drop_flip_v")
        layout.prop(self, "drag_drop_uv_scale_mode")
        layout.prop(self, "drag_drop_rq_z_rotation_fix")


def _operator_import_paths(filepath: str, directory: str = "", files: Any | None = None) -> list[Path]:
    result: list[Path] = []
    directory_path = Path(bpy.path.abspath(directory)) if directory else None

    if files:
        for item in files:
            name = getattr(item, "name", "")
            if not name:
                continue
            path = Path(name)
            if not path.is_absolute() and directory_path is not None:
                path = directory_path / path
            if path.suffix.lower() == ".mesh":
                result.append(path)

    if not result and filepath:
        path = Path(bpy.path.abspath(filepath))
        if path.suffix.lower() == ".mesh":
            result.append(path)

    unique: list[Path] = []
    seen: set[str] = set()
    for path in result:
        key = str(path).replace("\\", "/").lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(path)
    return unique


def _import_rq_mesh_object(
    filepath: Path,
    texture_root: str = "",
    flip_v: bool = True,
    uv_scale_mode: str = "AUTO",
    rq_z_rotation_fix: bool = True,
) -> tuple[bpy.types.Object, MeshData]:
    mesh_data = parse_mesh(filepath, uv_scale_mode)
    obj = _build_import_mesh(mesh_data, texture_root, flip_v)
    if rq_z_rotation_fix:
        # Держим поправку как object-level transform: так отображение в Blender
        # совпадает с RQ-ориентацией, а template-export не портит исходные
        # координаты, пока Apply object transform выключен.
        obj.rotation_euler[2] += math.pi
        obj[RQ_Z_ROTATION_FIX_PROP] = True
    else:
        obj[RQ_Z_ROTATION_FIX_PROP] = False
    return obj, mesh_data


def _report_import_result(operator: bpy.types.Operator, obj: bpy.types.Object, mesh_data: MeshData) -> tuple[int, int, int]:
    for warning in mesh_data.warnings[:5]:
        operator.report({"WARNING"}, warning)

    resolved = 0
    failed = 0
    for mat in obj.data.materials:
        value = str(mat.get(RESOLVED_TEXTURE_PATH_PROP, ""))
        if value.startswith("LOAD_FAILED:"):
            failed += 1
        elif value:
            resolved += 1

    missing = max(0, len(obj.data.materials) - resolved - failed)
    if missing:
        operator.report(
            {"WARNING"},
            f"Текстуры не найдены: {missing}. Укажи Texture root на папку rq_extracted или client с textures.",
        )
    if failed:
        operator.report({"WARNING"}, f"Текстуры найдены, но не загружены: {failed}")

    uv_scales = sorted({round(float(chunk.uv_scale), 4) for chunk in mesh_data.chunks})
    operator.report(
        {"INFO"},
        f"Импортировано: {obj.name}, chunks={len(mesh_data.chunks)}, vertices={mesh_data.vertex_count}, triangles={mesh_data.triangle_count}, textures={resolved}/{len(obj.data.materials)}, uv_scale={uv_scales}",
    )
    return resolved, failed, missing


class ImportRQMesh(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.rq_mesh"
    bl_label = "Import Royal Quest .mesh"
    bl_options = {"PRESET", "UNDO"}

    filename_ext = ".mesh"
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={"HIDDEN"})
    directory: StringProperty(subtype="DIR_PATH", options={"HIDDEN"})
    texture_root: StringProperty(
        name="Texture root",
        description="Необязательная папка с распакованными textures; нужна только для автоподключения картинок",
        default="",
        subtype="DIR_PATH",
    )
    flip_v: BoolProperty(
        name="Flip V",
        description="Перевернуть V-координату UV при импорте. В оригинальном RQ Model Lab просмотрщик делает именно так: (u, 1-v)",
        default=True,
    )
    uv_scale_mode: EnumProperty(
        name="UV scale",
        description="Как декодировать 16-битные UV. Auto использует штатный режим x4 и чинит signed seam-значения",
        items=UV_SCALE_MODE_ITEMS,
        default="AUTO",
    )
    rq_z_rotation_fix: BoolProperty(
        name="RQ Z 180° correction",
        description="Визуально разворачивает импортированный объект вокруг Blender Z на 180 градусов без переписывания вершин .mesh",
        default=True,
    )

    def invoke(self, context: bpy.types.Context, event: Any) -> set[str]:
        prefs = _addon_preferences(context)
        if prefs is not None:
            try:
                if not self.texture_root:
                    self.texture_root = str(getattr(prefs, "drag_drop_texture_root", "") or "")
            except Exception:
                pass
        return ImportHelper.invoke(self, context, event)

    def execute(self, context: bpy.types.Context) -> set[str]:
        paths = _operator_import_paths(self.filepath, self.directory, self.files)
        if not paths:
            self.report({"ERROR"}, "Не выбран .mesh файл для импорта")
            return {"CANCELLED"}

        imported = 0
        last_error = ""
        for path in paths:
            try:
                obj, mesh_data = _import_rq_mesh_object(
                    path,
                    self.texture_root,
                    self.flip_v,
                    self.uv_scale_mode,
                    self.rq_z_rotation_fix,
                )
                _report_import_result(self, obj, mesh_data)
                imported += 1
            except Exception as exc:
                last_error = f"{path.name}: {exc}"
                self.report({"ERROR"}, f"Не удалось импортировать .mesh {path.name}: {exc}")

        if imported <= 0:
            self.report({"ERROR"}, last_error or "Импорт не выполнен")
            return {"CANCELLED"}

        if imported > 1:
            self.report({"INFO"}, f"Импортировано .mesh файлов: {imported}/{len(paths)}")
        return {"FINISHED"}


class ImportRQMeshDrop(bpy.types.Operator):
    bl_idname = "import_scene.rq_mesh_drop"
    bl_label = "Drop Royal Quest .mesh"
    bl_options = {"UNDO", "INTERNAL"}

    filepath: StringProperty(subtype="FILE_PATH")
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={"HIDDEN"})
    directory: StringProperty(subtype="DIR_PATH", options={"HIDDEN"})

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = _addon_preferences(context)
        texture_root = ""
        flip_v = True
        uv_scale_mode = "AUTO"
        rq_z_rotation_fix = True
        if prefs is not None:
            texture_root = str(getattr(prefs, "drag_drop_texture_root", "") or "")
            flip_v = bool(getattr(prefs, "drag_drop_flip_v", True))
            uv_scale_mode = str(getattr(prefs, "drag_drop_uv_scale_mode", "AUTO") or "AUTO")
            rq_z_rotation_fix = bool(getattr(prefs, "drag_drop_rq_z_rotation_fix", True))

        paths = _operator_import_paths(self.filepath, self.directory, self.files)
        if not paths:
            self.report({"ERROR"}, "Перетащенный файл не является .mesh")
            return {"CANCELLED"}

        imported = 0
        last_error = ""
        for path in paths:
            try:
                obj, mesh_data = _import_rq_mesh_object(path, texture_root, flip_v, uv_scale_mode, rq_z_rotation_fix)
                _report_import_result(self, obj, mesh_data)
                imported += 1
            except Exception as exc:
                last_error = f"{path.name}: {exc}"
                self.report({"ERROR"}, f"Не удалось импортировать .mesh {path.name}: {exc}")

        if imported <= 0:
            self.report({"ERROR"}, last_error or "Drag-and-drop импорт не выполнен")
            return {"CANCELLED"}

        if imported > 1:
            self.report({"INFO"}, f"Drag-and-drop импортировано .mesh файлов: {imported}/{len(paths)}")
        return {"FINISHED"}



class ExportRQMesh(bpy.types.Operator, ExportHelper):
    bl_idname = "export_scene.rq_mesh"
    bl_label = "Export Royal Quest .mesh"
    bl_options = {"PRESET"}

    filename_ext = ".mesh"
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})
    apply_modifiers: BoolProperty(
        name="Apply modifiers",
        description="Применить модификаторы перед экспортом",
        default=False,
    )
    apply_object_transform: BoolProperty(
        name="Apply object transform",
        description="Записать координаты с учётом transform объекта",
        default=False,
    )
    prefer_template_patch: BoolProperty(
        name="Use original file as template",
        description="Если модель была импортирована из .mesh, обновить геометрию внутри исходного бинарного шаблона и сохранить неизвестные секции",
        default=True,
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        obj = context.active_object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Выбери Mesh-объект для экспорта")
            return {"CANCELLED"}

        out_path = Path(self.filepath)
        try:
            metadata = _load_metadata(obj)
            if self.prefer_template_patch and metadata is not None:
                ok, message = _patch_template_export(
                    context,
                    obj,
                    out_path,
                    metadata,
                    self.apply_modifiers,
                    self.apply_object_transform,
                )
                if ok:
                    self.report({"INFO"}, message)
                    return {"FINISHED"}
                self.report({"WARNING"}, message)

            ok, message = _minimal_export(
                context,
                obj,
                out_path,
                self.apply_modifiers,
                self.apply_object_transform,
            )
            if ok:
                self.report({"WARNING"}, message)
                return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, f"Не удалось экспортировать .mesh: {exc}")
            return {"CANCELLED"}

        self.report({"ERROR"}, "Экспорт не выполнен")
        return {"CANCELLED"}


# -----------------------------------------------------------------------------
# Drag-and-drop file handler + Menu/register.
# -----------------------------------------------------------------------------


if hasattr(bpy.types, "FileHandler"):
    class RQMeshFileHandler(bpy.types.FileHandler):
        bl_idname = "RQ_FH_mesh_import"
        bl_label = "Royal Quest .mesh drag-and-drop"
        bl_import_operator = ImportRQMeshDrop.bl_idname
        bl_file_extensions = ".mesh"

        @classmethod
        def poll_drop(cls, context: bpy.types.Context) -> bool:
            area = getattr(context, "area", None)
            if area is None:
                return True
            return area.type in {"VIEW_3D", "OUTLINER", "FILE_BROWSER"}
else:
    RQMeshFileHandler = None


def menu_func_import(self: Any, context: bpy.types.Context) -> None:
    self.layout.operator(ImportRQMesh.bl_idname, text="Royal Quest (.mesh)")


def menu_func_export(self: Any, context: bpy.types.Context) -> None:
    self.layout.operator(ExportRQMesh.bl_idname, text="Royal Quest (.mesh)")


def _registered_classes() -> tuple[type, ...]:
    classes: list[type] = [
        RQMeshAddonPreferences,
        ImportRQMesh,
        ImportRQMeshDrop,
        ExportRQMesh,
    ]
    if RQMeshFileHandler is not None:
        classes.append(RQMeshFileHandler)
    return tuple(classes)


def register() -> None:
    for cls in _registered_classes():
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister() -> None:
    try:
        bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    except Exception:
        pass
    try:
        bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    except Exception:
        pass
    for cls in reversed(_registered_classes()):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()
