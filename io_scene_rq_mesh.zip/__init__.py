bl_info = {
    "name": "Royal Quest .mesh Import/Export",
    "author": "OpenAI / based on RQ_Model_Lab_v21 parser",
    "version": (0, 1, 3),
    "blender": (3, 6, 0),
    "location": "File > Import/Export > Royal Quest (.mesh)",
    "description": "Import and export Royal Quest .mesh files. Geometry/UV/material import; safe template-based export when possible.",
    "category": "Import-Export",
}

import json
import math
import re
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper
from mathutils import Matrix, Vector

try:
    import bmesh
except Exception:  # pragma: no cover - Blender provides bmesh
    bmesh = None

CHUNK_HEADER = 12
META_PROP = "rq_mesh_metadata"
SOURCE_PATH_PROP = "rq_mesh_source_path"
TEXTURE_PATH_PROP = "rq_texture_path"


# -----------------------------------------------------------------------------
# Low-level .mesh helpers copied/adapted from RQ_Model_Lab_v21/rq_lab/formats.
# -----------------------------------------------------------------------------


def u32(data: bytes | bytearray, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def put_u32(data: bytearray, off: int, value: int) -> None:
    struct.pack_into("<I", data, off, int(value) & 0xFFFFFFFF)


@dataclass(frozen=True)
class Section:
    section_id: int
    offset: int
    end: int

    @property
    def size(self) -> int:
        return self.end - self.offset


def parse_sections(data: bytes) -> tuple[int, int, list[Section]]:
    if len(data) < 8:
        raise ValueError("Файл слишком маленький")

    declared_size = u32(data, 0)
    section_count = u32(data, 4)
    if section_count <= 0 or section_count > 512:
        raise ValueError(f"Подозрительное число секций: {section_count}")

    table_end = 8 + section_count * 8
    if table_end > len(data):
        raise ValueError("Таблица секций выходит за пределы файла")

    entries: list[tuple[int, int, int]] = []
    for i in range(section_count):
        pos = 8 + i * 8
        entries.append((i, u32(data, pos), u32(data, pos + 4)))

    sorted_offsets = sorted(off for _idx, _sid, off in entries if 0 < off <= len(data))
    sections: list[Section] = []
    for _idx, section_id, offset in entries:
        if offset >= len(data):
            end = len(data)
        else:
            next_offsets = [x for x in sorted_offsets if x > offset]
            end = next_offsets[0] if next_offsets else len(data)
        if end < offset:
            end = offset
        sections.append(Section(section_id, offset, end))
    return declared_size, section_count, sections


def section_bytes(data: bytes, sections: list[Section], section_id: int) -> bytes | None:
    for section in sections:
        if section.section_id == section_id:
            return data[section.offset : section.end]
    return None


def section_by_id(sections: list[Section], section_id: int) -> Section | None:
    for section in sections:
        if section.section_id == section_id:
            return section
    return None


def _read_cstring(data: bytes, offset: int) -> str:
    end = data.find(b"\x00", offset)
    if end == -1:
        end = len(data)
    return data[offset:end].decode("ascii", errors="replace")


def _decode_packed_normal(packed: int) -> tuple[float, float, float]:
    x = ((packed >> 0) & 0x3FF) / 511.0 * 2.0 - 1.0
    y = ((packed >> 10) & 0x3FF) / 511.0 * 2.0 - 1.0
    z = ((packed >> 20) & 0x3FF) / 511.0 * 2.0 - 1.0
    length = math.sqrt(x * x + y * y + z * z)
    if length < 1e-6:
        return (0.0, 0.0, 1.0)
    return (x / length, y / length, z / length)


def _encode_packed_normal(normal: tuple[float, float, float] | Vector) -> int:
    x, y, z = float(normal[0]), float(normal[1]), float(normal[2])
    length = math.sqrt(x * x + y * y + z * z)
    if length < 1e-6:
        x, y, z = 0.0, 0.0, 1.0
    else:
        x, y, z = x / length, y / length, z / length

    def enc(v: float) -> int:
        return max(0, min(1023, int(round((max(-1.0, min(1.0, v)) + 1.0) * 511.0 * 0.5))))

    return enc(x) | (enc(y) << 10) | (enc(z) << 20)


def _uv_offset_and_scale(stride: int) -> tuple[int, float]:
    if stride >= 20:
        return 12, 4.0 / 65535.0
    return 0, 0.0


def _read_vertex_uv(chunk: bytes, base: int, stride: int) -> tuple[float, float]:
    offset, scale = _uv_offset_and_scale(stride)
    if offset <= 0 or base + offset + 4 > len(chunk):
        return (0.0, 0.0)
    u = struct.unpack_from("<H", chunk, base + offset)[0]
    v = struct.unpack_from("<H", chunk, base + offset + 2)[0]
    return (u * scale, v * scale)


def _write_vertex_uv(raw: bytearray, base: int, stride: int, uv: tuple[float, float]) -> None:
    offset, _scale = _uv_offset_and_scale(stride)
    if offset <= 0 or base + offset + 4 > len(raw):
        return

    def enc(value: float) -> int:
        return max(0, min(65535, int(round(float(value) * 65535.0 / 4.0))))

    struct.pack_into("<H", raw, base + offset, enc(uv[0]))
    struct.pack_into("<H", raw, base + offset + 2, enc(uv[1]))


def _rq_uv_to_blender(uv: tuple[float, float], flip_v: bool = True) -> tuple[float, float]:
    u, v = float(uv[0]), float(uv[1])
    if flip_v:
        v = 1.0 - v
    return (u, v)


def _blender_uv_to_rq(uv: tuple[float, float], flip_v: bool = True) -> tuple[float, float]:
    u, v = float(uv[0]), float(uv[1])
    if flip_v:
        v = 1.0 - v
    return (u, v)


def _read_vertex_normal(chunk: bytes, base: int, stride: int) -> tuple[float, float, float]:
    if stride >= 20:
        packed = struct.unpack_from("<I", chunk, base + 16)[0]
        return _decode_packed_normal(packed)
    if stride >= 16:
        packed = struct.unpack_from("<I", chunk, base + 12)[0]
        return _decode_packed_normal(packed)
    return (0.0, 0.0, 1.0)


def _write_vertex_normal(raw: bytearray, base: int, stride: int, normal: tuple[float, float, float] | Vector) -> None:
    if stride >= 20 and base + 20 <= len(raw):
        struct.pack_into("<I", raw, base + 16, _encode_packed_normal(normal))
    elif stride >= 16 and base + 16 <= len(raw):
        struct.pack_into("<I", raw, base + 12, _encode_packed_normal(normal))


def _read_index_count(chunk: bytes, index_offset: int) -> tuple[int, int, int] | None:
    if index_offset + 4 > len(chunk):
        return None
    raw_index_count = u32(chunk, index_offset)
    if raw_index_count <= 0 or raw_index_count > 5_000_000:
        return None
    index_count = raw_index_count * 3 if raw_index_count < 3 else raw_index_count
    return raw_index_count, index_count, index_offset + 4


def _geometry_chunk_byte_size(chunk: bytes) -> int | None:
    if len(chunk) < CHUNK_HEADER + 16:
        return None

    vertex_count = u32(chunk, 4)
    stride = u32(chunk, 8)
    if not (3 <= vertex_count <= 500_000):
        return None
    if stride not in range(12, 65):
        return None

    index_offset = CHUNK_HEADER + vertex_count * stride
    index_info = _read_index_count(chunk, index_offset)
    if index_info is None:
        return None
    _raw_index_count, index_count, index_data_offset = index_info
    if index_data_offset + index_count * 2 > len(chunk):
        return None

    indices_end = index_data_offset + index_count * 2
    tail_offset = indices_end
    tail_bytes = len(chunk) - tail_offset
    if tail_bytes >= 6 and tail_bytes % 2 == 0:
        tail_count = (tail_bytes // 2 // 3) * 3
        if tail_count >= 3:
            tail_indices = struct.unpack_from(f"<{tail_count}H", chunk, tail_offset)
            if max(tail_indices) < vertex_count and any(tail_indices):
                return tail_offset + tail_count * 2
    return indices_end


@dataclass
class MeshChunk:
    vertices: list[tuple[float, float, float]]
    normals: list[tuple[float, float, float]]
    uvs: list[tuple[float, float]]
    indices: list[int]
    vertex_count: int
    stride: int
    texture_index: int = 0
    geom_offset: int = 0
    chunk_size: int = 0
    raw_index_count: int = 0
    primary_index_count: int = 0
    primary_index_data_offset: int = 0
    tail_index_count: int = 0
    tail_index_data_offset: int = 0


@dataclass
class MeshData:
    path: Path
    file_size: int
    declared_size: int
    textures: list[str] = field(default_factory=list)
    animblock_path: str | None = None
    chunks: list[MeshChunk] = field(default_factory=list)
    bone_palette: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def vertex_count(self) -> int:
        return sum(chunk.vertex_count for chunk in self.chunks)

    @property
    def triangle_count(self) -> int:
        return sum(len(chunk.indices) // 3 for chunk in self.chunks)


def _parse_geometry_chunk(chunk: bytes, geom_offset: int, texture_index: int) -> MeshChunk | None:
    if len(chunk) < CHUNK_HEADER + 16:
        return None

    vertex_count = u32(chunk, 4)
    stride = u32(chunk, 8)
    if not (3 <= vertex_count <= 500_000):
        return None
    if stride not in range(12, 65):
        return None

    vertex_start = CHUNK_HEADER
    vertex_bytes = vertex_count * stride
    index_offset = vertex_start + vertex_bytes
    if index_offset + 4 > len(chunk):
        return None

    index_info = _read_index_count(chunk, index_offset)
    if index_info is None:
        return None
    raw_index_count, index_count, index_data_offset = index_info
    if index_data_offset + index_count * 2 > len(chunk):
        return None

    indices = list(struct.unpack_from(f"<{index_count}H", chunk, index_data_offset))
    if not indices or max(indices) >= vertex_count:
        return None

    tail_offset = index_data_offset + index_count * 2
    tail_count = 0
    tail_bytes = len(chunk) - tail_offset
    if tail_bytes >= 6 and tail_bytes % 2 == 0:
        possible_tail_count = (tail_bytes // 2 // 3) * 3
        if possible_tail_count >= 3:
            tail_indices = struct.unpack_from(f"<{possible_tail_count}H", chunk, tail_offset)
            if max(tail_indices) < vertex_count and any(tail_indices):
                indices.extend(tail_indices)
                tail_count = possible_tail_count

    vertices: list[tuple[float, float, float]] = []
    normals: list[tuple[float, float, float]] = []
    uvs: list[tuple[float, float]] = []
    for i in range(vertex_count):
        base = vertex_start + i * stride
        px, py, pz = struct.unpack_from("<3f", chunk, base)
        vertices.append((px, py, pz))
        normals.append(_read_vertex_normal(chunk, base, stride))
        uvs.append(_read_vertex_uv(chunk, base, stride))

    return MeshChunk(
        vertices=vertices,
        normals=normals,
        uvs=uvs,
        indices=indices,
        vertex_count=vertex_count,
        stride=stride,
        texture_index=texture_index,
        geom_offset=geom_offset,
        chunk_size=len(chunk),
        raw_index_count=raw_index_count,
        primary_index_count=index_count,
        primary_index_data_offset=index_data_offset,
        tail_index_count=tail_count,
        tail_index_data_offset=tail_offset if tail_count else 0,
    )


def _is_submesh_base(geom: bytes, base: int) -> bool:
    if base + 0x34 > len(geom):
        return False
    if u32(geom, base + 8) != 5:
        return False
    if u32(geom, base + 0x10) != 0x30 or u32(geom, base + 0x14) != 1:
        return False
    if u32(geom, base + 0x1C) != 0xFFFFFFFF:
        return False
    if u32(geom, base + 0x20) != 0x54 or u32(geom, base + 0x24) != 2:
        return False
    rel = u32(geom, base + 0x28)
    sid = u32(geom, base + 0x2C)
    if sid != 4:
        return False
    abs_off = base + rel if base else rel
    if abs_off + 12 > len(geom):
        return False
    vertex_count = u32(geom, abs_off + 4)
    stride = u32(geom, abs_off + 8)
    return 3 <= vertex_count <= 500_000 and stride in range(12, 65)


def _find_submesh_bases(geom: bytes) -> list[int]:
    bases: set[int] = {0}
    if len(geom) >= 8 and u32(geom, 0) >= 2:
        second_base = u32(geom, 4)
        if 0x30 < second_base < len(geom):
            bases.add(second_base)
    for base in range(0, max(0, len(geom) - 0x60)):
        if base in bases or u32(geom, base + 8) != 5:
            continue
        if _is_submesh_base(geom, base):
            bases.add(base)
    return sorted(bases)


def _collect_geometry_offsets(geom: bytes, base: int = 0) -> list[int]:
    offsets: list[int] = []
    if base + 12 > len(geom):
        return offsets
    inner_count = u32(geom, base + 8) if base else u32(geom, 8)
    if inner_count != 5:
        return offsets
    for i in range(inner_count):
        entry = base + 0x10 + i * 8
        if entry + 8 > len(geom):
            continue
        rel = u32(geom, entry)
        section_id = u32(geom, entry + 4)
        if section_id not in (0, 4):
            continue
        offset = rel if base == 0 else base + rel
        if 0 < offset < len(geom):
            offsets.append(offset)
    return sorted(set(offsets))


def _parse_geometry_section(geom: bytes, warnings: list[str]) -> list[MeshChunk]:
    if len(geom) < 16:
        warnings.append("Секция геометрии слишком мала")
        return []

    chunks: list[MeshChunk] = []
    seen_offsets: set[int] = set()
    bases = _find_submesh_bases(geom)
    for texture_index, base in enumerate(bases):
        offsets = _collect_geometry_offsets(geom, base)
        for offset in offsets:
            if offset in seen_offsets:
                continue
            chunk_size = _geometry_chunk_byte_size(geom[offset:])
            if chunk_size is None:
                continue
            next_offsets = [x for x in offsets if x > offset]
            end = next_offsets[0] if next_offsets else len(geom)
            if end - offset < chunk_size:
                raw_chunk = geom[offset : offset + chunk_size]
            else:
                raw_chunk = geom[offset:end]
            parsed = _parse_geometry_chunk(raw_chunk, offset, texture_index)
            if parsed is None:
                continue
            seen_offsets.add(offset)
            chunks.append(parsed)

    if not chunks:
        warnings.append("Не найдены блоки геометрии")
    return chunks


def _parse_bone_palette_from_geom(geom: bytes) -> list[str]:
    if len(geom) < 32:
        return []

    candidate_offsets: list[int] = []
    try:
        inner_count = u32(geom, 8)
        if 1 <= inner_count <= 32:
            for i in range(inner_count):
                rel = u32(geom, 0x10 + i * 8)
                section_id = u32(geom, 0x10 + i * 8 + 4)
                if section_id == 0 and 0 < rel < len(geom):
                    candidate_offsets.append(rel)
    except Exception:
        pass

    for off in range(0, max(0, len(geom) - 16), 4):
        if off in candidate_offsets:
            continue
        count = u32(geom, off + 4) if off + 8 <= len(geom) else 0
        if 1 <= count <= 512 and off + 8 < len(geom):
            first_zero = geom.find(b"\x00", off + 8, min(len(geom), off + 80))
            if first_zero > off + 8:
                name = geom[off + 8:first_zero]
                if all(32 <= b < 127 for b in name) and any(65 <= b <= 122 for b in name):
                    candidate_offsets.append(off)

    for off in candidate_offsets:
        if off + 8 > len(geom):
            continue
        count = u32(geom, off + 4)
        if not (1 <= count <= 512):
            continue
        pos = off + 8
        names: list[str] = []
        ok = True
        for _ in range(count):
            end = geom.find(b"\x00", pos, min(len(geom), pos + 96))
            if end <= pos:
                ok = False
                break
            raw = geom[pos:end]
            if not all(32 <= b < 127 for b in raw):
                ok = False
                break
            name = raw.decode("ascii", errors="replace")
            names.append(name)
            pos = end + 1 + 24
            if pos > len(geom) + 24:
                ok = False
                break
        if ok and len(names) == count:
            good_names = sum(1 for n in names if "_" in n or n in {"Head", "Chest", "Pelvis", "Spine", "Navel"})
            if good_names >= max(3, count // 8):
                return names
    return []


def _parse_texture_section(section: bytes) -> list[str]:
    if len(section) >= 4:
        count = u32(section, 0)
        if 1 <= count <= 1024:
            pos = 4
            parsed: list[str] = []
            for _ in range(count):
                if pos + 2 > len(section):
                    break
                while pos + 1 < len(section):
                    code = struct.unpack_from("<H", section, pos)[0]
                    pos += 2
                    if code == 0:
                        break
                if pos >= len(section):
                    break
                end = section.find(b"\x00", pos)
                if end == -1:
                    break
                path = section[pos:end].decode("ascii", errors="replace")
                pos = end + 1
                if "/" in path or "\\" in path or "." in path:
                    parsed.append(path.replace("\\", "/"))
            if parsed:
                return parsed

    textures: list[str] = []
    for match in re.findall(rb"[\x20-\x7e]{4,}", section):
        value = match.decode("ascii", errors="replace").replace("\\", "/")
        if ("/" in value or "." in value) and value not in textures:
            textures.append(value)
    return textures


def parse_mesh(path: Path) -> MeshData:
    data = path.read_bytes()
    declared_size, _section_count, sections = parse_sections(data)
    warnings: list[str] = []
    if declared_size != len(data):
        warnings.append(f"Размер в заголовке ({declared_size}) не совпадает с файлом ({len(data)})")

    textures: list[str] = []
    texture_section = section_bytes(data, sections, 2)
    if texture_section:
        textures = _parse_texture_section(texture_section)

    animblock_path: str | None = None
    anim_section = section_bytes(data, sections, 6)
    if anim_section:
        raw = _read_cstring(anim_section, 0).strip()
        if raw:
            animblock_path = raw.replace("\\", "/")

    geom_section = section_bytes(data, sections, 3)
    chunks: list[MeshChunk] = []
    bone_palette: list[str] = []
    if geom_section:
        chunks = _parse_geometry_section(geom_section, warnings)
        bone_palette = _parse_bone_palette_from_geom(geom_section)
    else:
        warnings.append("Секция геометрии не найдена")

    if not chunks:
        warnings.append("Не удалось извлечь вершины/индексы")

    return MeshData(
        path=path.resolve(),
        file_size=len(data),
        declared_size=declared_size,
        textures=textures,
        animblock_path=animblock_path,
        chunks=chunks,
        bone_palette=bone_palette,
        warnings=warnings,
    )


# -----------------------------------------------------------------------------
# Blender material/import helpers.
# -----------------------------------------------------------------------------


def _safe_name(value: str, fallback: str) -> str:
    name = Path(value.replace("\\", "/")).name if value else ""
    name = name or fallback
    return name[:63]


def _texture_candidates(texture_path: str, mesh_path: Path, texture_root: str = "") -> list[Path]:
    normalized = texture_path.replace("\\", "/")
    candidates: list[Path] = []
    raw = Path(normalized)
    if raw.is_absolute():
        candidates.append(raw)

    bases: list[Path] = []
    if texture_root:
        bases.append(Path(bpy.path.abspath(texture_root)))
    bases.append(mesh_path.parent)
    bases.extend(list(mesh_path.parents)[:6])

    for base in bases:
        candidates.append(base / normalized)
        if normalized.lower().startswith("textures/"):
            candidates.append(base / normalized[len("textures/"):])

    expanded: list[Path] = []
    for item in candidates:
        expanded.append(item)
        stem = item.with_suffix("")
        suffix = item.suffix.lower()
        if suffix in {".tga", ".dds", ".png"}:
            expanded.extend(
                [
                    stem.with_suffix(".dds"),
                    stem.with_name(stem.name + "_dxt1").with_suffix(".dds"),
                    stem.with_name(stem.name + "_dxt5").with_suffix(".dds"),
                    stem.with_suffix(".tga"),
                    stem.with_suffix(".png"),
                ]
            )

    unique: list[Path] = []
    seen: set[str] = set()
    for item in expanded:
        key = str(item).lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique


def _find_texture_file(texture_path: str, mesh_path: Path, texture_root: str = "") -> Path | None:
    for candidate in _texture_candidates(texture_path, mesh_path, texture_root):
        try:
            if candidate.exists() and candidate.is_file():
                return candidate
        except OSError:
            continue
    return None


def _make_material(texture_path: str, mesh_path: Path, texture_root: str = "") -> bpy.types.Material:
    mat_name = _safe_name(texture_path, "rq_material")
    mat = bpy.data.materials.new(mat_name)
    mat[TEXTURE_PATH_PROP] = texture_path
    mat.use_nodes = True

    texture_file = _find_texture_file(texture_path, mesh_path, texture_root)
    if texture_file is None:
        return mat

    try:
        image = bpy.data.images.load(str(texture_file), check_existing=True)
    except Exception:
        return mat

    try:
        nodes = mat.node_tree.nodes
        bsdf = nodes.get("Principled BSDF")
        tex = nodes.new(type="ShaderNodeTexImage")
        tex.image = image
        mat.node_tree.links.new(tex.outputs.get("Color"), bsdf.inputs.get("Base Color"))
        if "Alpha" in tex.outputs and "Alpha" in bsdf.inputs:
            mat.node_tree.links.new(tex.outputs.get("Alpha"), bsdf.inputs.get("Alpha"))
            mat.blend_method = "BLEND"
            mat.use_screen_refraction = True
    except Exception:
        pass
    return mat


def _build_import_mesh(mesh_data: MeshData, texture_root: str = "", flip_v: bool = True) -> bpy.types.Object:
    vertices: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int]] = []
    face_chunk_indices: list[int] = []
    face_texture_indices: list[int] = []
    loop_uvs: list[tuple[float, float]] = []
    metadata_chunks: list[dict[str, Any]] = []

    for chunk_index, chunk in enumerate(mesh_data.chunks):
        start_vertex = len(vertices)
        start_face = len(faces)
        vertices.extend(chunk.vertices)

        for tri_pos in range(0, len(chunk.indices) - 2, 3):
            i0 = chunk.indices[tri_pos]
            i1 = chunk.indices[tri_pos + 1]
            i2 = chunk.indices[tri_pos + 2]
            if i0 >= chunk.vertex_count or i1 >= chunk.vertex_count or i2 >= chunk.vertex_count:
                continue
            faces.append((start_vertex + i0, start_vertex + i1, start_vertex + i2))
            face_chunk_indices.append(chunk_index)
            face_texture_indices.append(chunk.texture_index)
            loop_uvs.extend(
                [
                    _rq_uv_to_blender(chunk.uvs[i0], flip_v),
                    _rq_uv_to_blender(chunk.uvs[i1], flip_v),
                    _rq_uv_to_blender(chunk.uvs[i2], flip_v),
                ]
            )

        metadata_chunks.append(
            {
                "chunk_index": chunk_index,
                "start_vertex": start_vertex,
                "vertex_count": chunk.vertex_count,
                "start_face": start_face,
                "face_count": len(faces) - start_face,
                "stride": chunk.stride,
                "texture_index": chunk.texture_index,
                "geom_offset": chunk.geom_offset,
                "chunk_size": chunk.chunk_size,
                "raw_index_count": chunk.raw_index_count,
                "primary_index_count": chunk.primary_index_count,
                "primary_index_data_offset": chunk.primary_index_data_offset,
                "tail_index_count": chunk.tail_index_count,
                "tail_index_data_offset": chunk.tail_index_data_offset,
            }
        )

    blend_mesh = bpy.data.meshes.new(mesh_data.path.stem)
    blend_mesh.from_pydata(vertices, [], faces)
    blend_mesh.update()

    uv_layer = blend_mesh.uv_layers.new(name="RQ_UV")
    uv_cursor = 0
    for poly in blend_mesh.polygons:
        for loop_index in poly.loop_indices:
            if uv_cursor < len(loop_uvs):
                uv_layer.data[loop_index].uv = loop_uvs[uv_cursor]
            uv_cursor += 1
    blend_mesh.uv_layers.active = uv_layer
    uv_layer.active_render = True

    obj = bpy.data.objects.new(mesh_data.path.stem, blend_mesh)
    bpy.context.collection.objects.link(obj)

    texture_count = max(len(mesh_data.textures), max(face_texture_indices, default=-1) + 1)
    for i in range(texture_count):
        texture_path = mesh_data.textures[i] if i < len(mesh_data.textures) else f"material_{i}"
        obj.data.materials.append(_make_material(texture_path, mesh_data.path, texture_root))

    for poly_index, poly in enumerate(blend_mesh.polygons):
        texture_index = face_texture_indices[poly_index] if poly_index < len(face_texture_indices) else 0
        poly.material_index = min(max(texture_index, 0), max(0, len(obj.data.materials) - 1))

    metadata = {
        "format": "rq_mesh_blender_addon_v1",
        "source_path": str(mesh_data.path),
        "file_size": mesh_data.file_size,
        "declared_size": mesh_data.declared_size,
        "textures": mesh_data.textures,
        "animblock_path": mesh_data.animblock_path,
        "bone_palette": mesh_data.bone_palette,
        "uv_flip_v": bool(flip_v),
        "chunks": metadata_chunks,
    }
    obj[META_PROP] = json.dumps(metadata, ensure_ascii=False)
    obj[SOURCE_PATH_PROP] = str(mesh_data.path)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    return obj


# -----------------------------------------------------------------------------
# Export helpers: safe patching of original .mesh, and minimal new .mesh writer.
# -----------------------------------------------------------------------------


def _material_texture_path(material: bpy.types.Material | None, fallback_index: int) -> str:
    if material is not None and TEXTURE_PATH_PROP in material:
        return str(material[TEXTURE_PATH_PROP]).replace("\\", "/")
    if material is not None:
        name = material.name.split(".")[0]
        return name or f"material_{fallback_index}.tga"
    return f"material_{fallback_index}.tga"


def _triangulated_mesh_from_object(context: bpy.types.Context, obj: bpy.types.Object, apply_modifiers: bool) -> bpy.types.Mesh:
    if obj.type != "MESH":
        raise ValueError("Для экспорта должен быть выбран Mesh-объект")

    if apply_modifiers:
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = bpy.data.meshes.new_from_object(eval_obj, depsgraph=depsgraph, preserve_all_data_layers=True)
    else:
        mesh = obj.data.copy()

    if any(len(poly.vertices) != 3 for poly in mesh.polygons):
        if bmesh is None:
            bpy.data.meshes.remove(mesh)
            raise ValueError("В модели есть не треугольные полигоны, а bmesh недоступен")
        bm = bmesh.new()
        bm.from_mesh(mesh)
        faces = [face for face in bm.faces if len(face.verts) > 3]
        if faces:
            bmesh.ops.triangulate(bm, faces=faces)
        bm.to_mesh(mesh)
        bm.free()
        mesh.update()
    return mesh


def _face_loop_uv(mesh: bpy.types.Mesh, polygon: bpy.types.MeshPolygon, loop_position: int) -> tuple[float, float]:
    if not mesh.uv_layers.active:
        return (0.0, 0.0)
    loop_index = polygon.loop_indices[loop_position]
    uv = mesh.uv_layers.active.data[loop_index].uv
    return (float(uv.x), float(uv.y))


def _face_loop_normal(mesh: bpy.types.Mesh, polygon: bpy.types.MeshPolygon, loop_position: int) -> tuple[float, float, float]:
    try:
        loop = mesh.loops[polygon.loop_indices[loop_position]]
        normal = loop.normal
        return (float(normal.x), float(normal.y), float(normal.z))
    except Exception:
        normal = polygon.normal
        return (float(normal.x), float(normal.y), float(normal.z))


def _load_metadata(obj: bpy.types.Object) -> dict[str, Any] | None:
    if META_PROP not in obj:
        return None
    try:
        loaded = json.loads(str(obj[META_PROP]))
    except Exception:
        return None
    if not isinstance(loaded, dict) or loaded.get("format") != "rq_mesh_blender_addon_v1":
        return None
    return loaded


def _object_matrix_for_export(obj: bpy.types.Object, apply_object_transform: bool) -> Matrix:
    return obj.matrix_world.copy() if apply_object_transform else Matrix.Identity(4)


def _patch_template_export(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    out_path: Path,
    metadata: dict[str, Any],
    apply_modifiers: bool,
    apply_object_transform: bool,
) -> tuple[bool, str]:
    source_path = Path(str(metadata.get("source_path") or obj.get(SOURCE_PATH_PROP, "")))
    if not source_path.exists():
        return False, "исходный .mesh не найден, будет создан минимальный файл"

    chunks_meta = metadata.get("chunks")
    if not isinstance(chunks_meta, list) or not chunks_meta:
        return False, "нет данных о чанках исходного файла"

    uv_flip_v = bool(metadata.get("uv_flip_v", True))

    mesh = _triangulated_mesh_from_object(context, obj, apply_modifiers)
    transform = _object_matrix_for_export(obj, apply_object_transform)
    try:
        data = bytearray(source_path.read_bytes())
        _declared_size, _section_count, sections = parse_sections(bytes(data))
        geom_section = section_by_id(sections, 3)
        if geom_section is None:
            return False, "в исходном файле нет секции геометрии"

        mesh.calc_loop_triangles()
        mesh.update(calc_edges=False)

        for chunk in chunks_meta:
            start_vertex = int(chunk["start_vertex"])
            vertex_count = int(chunk["vertex_count"])
            start_face = int(chunk["start_face"])
            face_count = int(chunk["face_count"])
            stride = int(chunk["stride"])
            geom_offset = int(chunk["geom_offset"])
            primary_index_count = int(chunk.get("primary_index_count", 0))
            primary_index_data_offset = int(chunk.get("primary_index_data_offset", 0))
            tail_index_count = int(chunk.get("tail_index_count", 0))
            tail_index_data_offset = int(chunk.get("tail_index_data_offset", 0))

            if start_vertex + vertex_count > len(mesh.vertices):
                return False, "количество вершин изменено; template patch невозможен"
            if start_face + face_count > len(mesh.polygons):
                return False, "количество полигонов изменено; template patch невозможен"
            if face_count * 3 != primary_index_count + tail_index_count:
                return False, "число индексов чанка не совпадает с исходным"

            chunk_file_offset = geom_section.offset + geom_offset
            vertex_start = chunk_file_offset + CHUNK_HEADER

            for local_index in range(vertex_count):
                vertex = mesh.vertices[start_vertex + local_index]
                co = transform @ vertex.co
                base = vertex_start + local_index * stride
                if base + 12 > len(data):
                    return False, "выход за границы файла при записи вершин"
                struct.pack_into("<3f", data, base, float(co.x), float(co.y), float(co.z))
                _write_vertex_normal(data, base, stride, vertex.normal)

            indices: list[int] = []
            per_vertex_uv: dict[int, tuple[float, float]] = {}
            for face_index in range(start_face, start_face + face_count):
                polygon = mesh.polygons[face_index]
                if len(polygon.vertices) != 3:
                    return False, "после триангуляции найден не треугольный полигон"
                for loop_pos, vertex_index in enumerate(polygon.vertices):
                    local_index = int(vertex_index) - start_vertex
                    if local_index < 0 or local_index >= vertex_count:
                        return False, "вершины чанков перемешаны; template patch невозможен"
                    indices.append(local_index)
                    blender_uv = _face_loop_uv(mesh, polygon, loop_pos)
                    per_vertex_uv[local_index] = _blender_uv_to_rq(blender_uv, uv_flip_v)

            for local_index, uv in per_vertex_uv.items():
                base = vertex_start + local_index * stride
                _write_vertex_uv(data, base, stride, uv)

            if len(indices) != primary_index_count + tail_index_count:
                return False, "число индексов после экспорта не совпало с исходным"
            if max(indices, default=0) > 65535:
                return False, "индекс вершины больше 65535"

            primary = indices[:primary_index_count]
            if primary:
                index_abs = chunk_file_offset + primary_index_data_offset
                if index_abs + len(primary) * 2 > len(data):
                    return False, "выход за границы файла при записи индексов"
                struct.pack_into(f"<{len(primary)}H", data, index_abs, *primary)

            if tail_index_count:
                tail = indices[primary_index_count:]
                tail_abs = chunk_file_offset + tail_index_data_offset
                if tail_abs + len(tail) * 2 > len(data):
                    return False, "выход за границы файла при записи tail-индексов"
                struct.pack_into(f"<{len(tail)}H", data, tail_abs, *tail)

        out_path.write_bytes(bytes(data))
        return True, "экспорт выполнен через безопасное обновление исходного шаблона"
    finally:
        bpy.data.meshes.remove(mesh)


def _build_texture_section(texture_paths: list[str]) -> bytes:
    raw = bytearray()
    raw += struct.pack("<I", len(texture_paths))
    for path in texture_paths:
        name = Path(path.replace("\\", "/")).stem
        for ch in name:
            raw += struct.pack("<H", ord(ch))
        raw += struct.pack("<H", 0)
        raw += path.replace("\\", "/").encode("ascii", errors="replace") + b"\x00"
    return bytes(raw)


def _build_geometry_chunk(
    vertices: list[tuple[Vector, tuple[float, float], tuple[float, float, float]]],
    indices: list[int],
) -> bytes:
    if len(vertices) > 65535:
        raise ValueError("Один .mesh chunk не может иметь больше 65535 вершин")
    if len(indices) % 3 != 0:
        raise ValueError("Индексы чанка не кратны трём")

    raw = bytearray()
    raw += struct.pack("<III", 0, len(vertices), 20)
    for co, uv, normal in vertices:
        raw += struct.pack("<3f", float(co.x), float(co.y), float(co.z))
        u = max(0, min(65535, int(round(float(uv[0]) * 65535.0 / 4.0))))
        v = max(0, min(65535, int(round(float(uv[1]) * 65535.0 / 4.0))))
        raw += struct.pack("<HHI", u, v, _encode_packed_normal(normal))
    raw += struct.pack("<I", len(indices))
    raw += struct.pack(f"<{len(indices)}H", *indices)
    return bytes(raw)


def _submesh_header(first_chunk_rel: int, second_chunk_rel: int | None = None) -> bytes:
    raw = bytearray(0x40)
    put_u32(raw, 0x08, 5)
    put_u32(raw, 0x10, 0x30)
    put_u32(raw, 0x14, 1)
    put_u32(raw, 0x18, 0)
    put_u32(raw, 0x1C, 0xFFFFFFFF)
    put_u32(raw, 0x20, 0x54)
    put_u32(raw, 0x24, 2)
    put_u32(raw, 0x28, first_chunk_rel)
    put_u32(raw, 0x2C, 4)
    if second_chunk_rel is not None:
        put_u32(raw, 0x30, second_chunk_rel)
        put_u32(raw, 0x34, 4)
    return bytes(raw)


def _build_geometry_section(chunks: list[bytes]) -> bytes:
    raw = bytearray()
    for chunk in chunks:
        base = len(raw)
        raw += _submesh_header(0x40)
        raw += chunk
        while len(raw) % 4:
            raw += b"\x00"
        # Keep base variable intentionally: scanner finds each header by its byte offset.
        _ = base
    return bytes(raw)


def _build_minimal_mesh_file(texture_paths: list[str], geometry_chunks: list[bytes]) -> bytes:
    texture_section = _build_texture_section(texture_paths)
    geometry_section = _build_geometry_section(geometry_chunks)
    section_count = 2
    header_size = 8 + section_count * 8
    texture_offset = header_size
    geometry_offset = texture_offset + len(texture_section)
    declared_size = geometry_offset + len(geometry_section)
    raw = bytearray()
    raw += struct.pack("<II", declared_size, section_count)
    raw += struct.pack("<II", 2, texture_offset)
    raw += struct.pack("<II", 3, geometry_offset)
    raw += texture_section
    raw += geometry_section
    return bytes(raw)


def _minimal_export(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    out_path: Path,
    apply_modifiers: bool,
    apply_object_transform: bool,
) -> tuple[bool, str]:
    mesh = _triangulated_mesh_from_object(context, obj, apply_modifiers)
    transform = _object_matrix_for_export(obj, apply_object_transform)
    metadata = _load_metadata(obj)
    uv_flip_v = bool(metadata.get("uv_flip_v", True)) if metadata is not None else True
    try:
        mesh.calc_loop_triangles()
        mesh.update(calc_edges=False)
        material_count = max(1, len(obj.data.materials))
        texture_paths = [
            _material_texture_path(obj.data.materials[i] if i < len(obj.data.materials) else None, i)
            for i in range(material_count)
        ]

        chunk_bytes: list[bytes] = []
        chunk_texture_paths: list[str] = []
        for material_index in range(material_count):
            chunk_vertices: list[tuple[Vector, tuple[float, float], tuple[float, float, float]]] = []
            chunk_indices: list[int] = []
            vertex_map: dict[tuple[int, int, int, int], int] = {}

            def flush() -> None:
                nonlocal chunk_vertices, chunk_indices, vertex_map
                if chunk_vertices and chunk_indices:
                    chunk_bytes.append(_build_geometry_chunk(chunk_vertices, chunk_indices))
                    chunk_texture_paths.append(texture_paths[material_index])
                chunk_vertices = []
                chunk_indices = []
                vertex_map = {}

            for polygon in mesh.polygons:
                poly_mat = min(max(int(polygon.material_index), 0), material_count - 1)
                if poly_mat != material_index:
                    continue
                local_indices: list[int] = []
                for loop_pos, vertex_index in enumerate(polygon.vertices):
                    blender_uv = _face_loop_uv(mesh, polygon, loop_pos)
                    rq_uv = _blender_uv_to_rq(blender_uv, uv_flip_v)
                    uv_key = (int(round(rq_uv[0] * 100000.0)), int(round(rq_uv[1] * 100000.0)))
                    key = (int(vertex_index), uv_key[0], uv_key[1], loop_pos)
                    if key not in vertex_map:
                        if len(chunk_vertices) >= 65535:
                            flush()
                        vertex = mesh.vertices[int(vertex_index)]
                        co = transform @ vertex.co
                        normal = _face_loop_normal(mesh, polygon, loop_pos)
                        vertex_map[key] = len(chunk_vertices)
                        chunk_vertices.append((co, rq_uv, normal))
                    local_indices.append(vertex_map[key])
                if len(local_indices) == 3:
                    chunk_indices.extend(local_indices)
            flush()

        if not chunk_bytes:
            raise ValueError("Нет треугольников для экспорта")

        out_path.write_bytes(_build_minimal_mesh_file(chunk_texture_paths, chunk_bytes))
        return True, "создан минимальный .mesh; для игры лучше экспортировать поверх импортированного шаблона"
    finally:
        bpy.data.meshes.remove(mesh)


# -----------------------------------------------------------------------------
# Blender operators.
# -----------------------------------------------------------------------------


class ImportRQMesh(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.rq_mesh"
    bl_label = "Import Royal Quest .mesh"
    bl_options = {"PRESET", "UNDO"}

    filename_ext = ".mesh"
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})
    texture_root: StringProperty(
        name="Texture root",
        description="Необязательная папка с распакованными textures; нужна только для автоподключения картинок",
        default="",
        subtype="DIR_PATH",
    )
    flip_v: BoolProperty(
        name="Flip V",
        description="Перевернуть V-координату UV при импорте. В оригинальном RQ Model Lab просмотрщик делает именно так: (u, 1-v)",
        default=True,
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        try:
            mesh_data = parse_mesh(Path(self.filepath))
            obj = _build_import_mesh(mesh_data, self.texture_root, self.flip_v)
        except Exception as exc:
            self.report({"ERROR"}, f"Не удалось импортировать .mesh: {exc}")
            return {"CANCELLED"}

        for warning in mesh_data.warnings[:5]:
            self.report({"WARNING"}, warning)
        self.report(
            {"INFO"},
            f"Импортировано: {obj.name}, chunks={len(mesh_data.chunks)}, vertices={mesh_data.vertex_count}, triangles={mesh_data.triangle_count}",
        )
        return {"FINISHED"}


class ExportRQMesh(bpy.types.Operator, ExportHelper):
    bl_idname = "export_scene.rq_mesh"
    bl_label = "Export Royal Quest .mesh"
    bl_options = {"PRESET"}

    filename_ext = ".mesh"
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})
    apply_modifiers: BoolProperty(
        name="Apply modifiers",
        description="Применить модификаторы перед экспортом",
        default=False,
    )
    apply_object_transform: BoolProperty(
        name="Apply object transform",
        description="Записать координаты с учётом transform объекта",
        default=False,
    )
    prefer_template_patch: BoolProperty(
        name="Use original file as template",
        description="Если модель была импортирована из .mesh, обновить геометрию внутри исходного бинарного шаблона и сохранить неизвестные секции",
        default=True,
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        obj = context.active_object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Выбери Mesh-объект для экспорта")
            return {"CANCELLED"}

        out_path = Path(self.filepath)
        try:
            metadata = _load_metadata(obj)
            if self.prefer_template_patch and metadata is not None:
                ok, message = _patch_template_export(
                    context,
                    obj,
                    out_path,
                    metadata,
                    self.apply_modifiers,
                    self.apply_object_transform,
                )
                if ok:
                    self.report({"INFO"}, message)
                    return {"FINISHED"}
                self.report({"WARNING"}, message)

            ok, message = _minimal_export(
                context,
                obj,
                out_path,
                self.apply_modifiers,
                self.apply_object_transform,
            )
            if ok:
                self.report({"WARNING"}, message)
                return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, f"Не удалось экспортировать .mesh: {exc}")
            return {"CANCELLED"}

        self.report({"ERROR"}, "Экспорт не выполнен")
        return {"CANCELLED"}


# -----------------------------------------------------------------------------
# Menu/register.
# -----------------------------------------------------------------------------


def menu_func_import(self: Any, context: bpy.types.Context) -> None:
    self.layout.operator(ImportRQMesh.bl_idname, text="Royal Quest (.mesh)")


def menu_func_export(self: Any, context: bpy.types.Context) -> None:
    self.layout.operator(ExportRQMesh.bl_idname, text="Royal Quest (.mesh)")


classes = (
    ImportRQMesh,
    ExportRQMesh,
)


def register() -> None:
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister() -> None:
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
